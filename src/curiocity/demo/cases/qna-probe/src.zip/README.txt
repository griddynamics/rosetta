This is a scratch workspace for the qna-probe case. Create greeting.txt here.
