package com.bezkoder.spring.datajpa.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for tutorials. All endpoints are served under the {@code /api}
 * base path. This is the existing pattern to follow when adding new endpoints.
 */
@CrossOrigin(origins = {"http://localhost:8081", "http://localhost:3000"})
@RestController
@RequestMapping("/api")
public class TutorialController {

	@GetMapping("/tutorials")
	public ResponseEntity<List<String>> getAllTutorials(
			@RequestParam(required = false) String title) {
		try {
			List<String> tutorials = new ArrayList<>();
			return new ResponseEntity<>(tutorials, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
