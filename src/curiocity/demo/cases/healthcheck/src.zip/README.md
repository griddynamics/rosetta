# spring-boot-server (demo subset)

A minimal Spring Boot backend skeleton derived from the bezkoder
`spring-boot-react-mysql` sample. Trimmed to a single application class and one
REST controller (`TutorialController`) so a coding agent has a real, idiomatic
pattern to extend.

- Package: `com.bezkoder.spring.datajpa`
- REST base path: `/api` (see `TutorialController`)
- Sources under `spring-boot-server/src/main/java`

No build tooling (Maven wrapper, target/) is included — this subset is for
source-level tasks only.
