import http from "../http-common";

class TutorialDataService {
  getAll() {
    return http.get("/tutorials");
  }

  get(id) {
    return http.get(`/tutorials/${id}`);
  }

  create(data) {
    return http.post("/tutorials", data);
  }

  update(id, data) {
    return http.put(`/tutorials/${id}`, data);
  }

  delete(id) {
    return http.delete(`/tutorials/${id}`);
  }

  deleteAll() {
    return http.delete(`/tutorials`);
  }

  findByTitle(title) {
    return http.get(`/tutorials?title=${title}`);
  }

  // Comments
  getComments(tutorialId) {
    return http.get(`/tutorials/${tutorialId}/comments`);
  }

  createComment(tutorialId, data) {
    return http.post(`/tutorials/${tutorialId}/comments`, data);
  }

  deleteComment(commentId) {
    return http.delete(`/comments/${commentId}`);
  }

  getCommentCount(tutorialId) {
    return http.get(`/tutorials/${tutorialId}/comments/count`);
  }

  // Ratings
  getRatings(tutorialId) {
    return http.get(`/tutorials/${tutorialId}/ratings`);
  }

  createOrUpdateRating(tutorialId, data) {
    return http.post(`/tutorials/${tutorialId}/ratings`, data);
  }

  getRatingStats(tutorialId) {
    return http.get(`/tutorials/${tutorialId}/ratings/stats`);
  }

  getUserRating(tutorialId, userIdentifier) {
    return http.get(`/tutorials/${tutorialId}/ratings/user/${userIdentifier}`);
  }

  deleteRating(ratingId) {
    return http.delete(`/ratings/${ratingId}`);
  }

  // Special queries
  getTopRated(minRatings = 1, limit = 10) {
    return http.get(`/tutorials/top-rated?minRatings=${minRatings}&limit=${limit}`);
  }

  getMostDiscussed(limit = 10) {
    return http.get(`/tutorials/most-discussed?limit=${limit}`);
  }
}

export default new TutorialDataService();