import React, { Component } from "react";
import TutorialDataService from "../services/tutorial.service";
import { withRouter } from '../common/with-router';
import { Link } from "react-router-dom";
import StarRating from "./star-rating.component";
import Comments from "./comments.component";

class TutorialView extends Component {
  constructor(props) {
    super(props);
    this.getTutorial = this.getTutorial.bind(this);
    this.handleRatingChange = this.handleRatingChange.bind(this);
    this.loadRatingStats = this.loadRatingStats.bind(this);

    this.state = {
      currentTutorial: {
        id: null,
        title: "",
        description: "",
        published: false
      },
      message: "",
      ratingStats: {
        averageRating: 0,
        ratingCount: 0
      },
      userRating: 0,
      username: localStorage.getItem('username') || '',
      loading: true
    };
  }

  componentDidMount() {
    this.getTutorial(this.props.router.params.id);
    this.loadRatingStats(this.props.router.params.id);
    this.loadUserRating(this.props.router.params.id);
  }

  getTutorial(id) {
    TutorialDataService.get(id)
      .then(response => {
        this.setState({
          currentTutorial: response.data,
          loading: false
        });
      })
      .catch(e => {
        console.log(e);
        this.setState({ loading: false });
      });
  }

  loadRatingStats(tutorialId) {
    TutorialDataService.getRatingStats(tutorialId)
      .then(response => {
        this.setState({
          ratingStats: response.data
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  loadUserRating(tutorialId) {
    const username = localStorage.getItem('username');
    if (username) {
      TutorialDataService.getUserRating(tutorialId, username)
        .then(response => {
          this.setState({
            userRating: response.data.stars
          });
        })
        .catch(e => {
          // User hasn't rated yet, ignore error
        });
    }
  }

  handleRatingChange(stars) {
    const { username } = this.state;
    if (!username || username.trim() === '') {
      const name = prompt('Please enter your name to rate:');
      if (!name || name.trim() === '') {
        return;
      }
      this.setState({ username: name });
      localStorage.setItem('username', name);
    }

    const userIdentifier = username || localStorage.getItem('username');
    
    TutorialDataService.createOrUpdateRating(this.state.currentTutorial.id, {
      stars: stars,
      userIdentifier: userIdentifier
    })
      .then(() => {
        this.setState({ 
          userRating: stars,
          message: "Rating submitted successfully!"
        });
        setTimeout(() => this.setState({ message: "" }), 3000);
        this.loadRatingStats(this.state.currentTutorial.id);
      })
      .catch(e => {
        console.log(e);
        this.setState({ message: "Error submitting rating" });
      });
  }

  render() {
    const { currentTutorial, loading, ratingStats, userRating, message } = this.state;

    if (loading) {
      return (
        <div className="container mt-4">
          <div className="text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="sr-only">Loading...</span>
            </div>
            <p className="mt-2">Loading tutorial...</p>
          </div>
        </div>
      );
    }

    if (!currentTutorial.id) {
      return (
        <div className="container mt-4">
          <div className="alert alert-warning" role="alert">
            Tutorial not found.
          </div>
          <Link to="/tutorials" className="btn btn-primary">
            Back to Tutorials
          </Link>
        </div>
      );
    }

    return (
      <div className="container mt-4">
        {/* Header with back button and edit button */}
        <div className="mb-4 flex justify-between items-center">
          <Link to="/tutorials" className="btn btn-outline-secondary">
            ← Back to Tutorials
          </Link>
          <Link to={`/tutorials/${currentTutorial.id}/edit`} className="btn btn-primary">
            ✏️ Edit Tutorial
          </Link>
        </div>

        {/* Tutorial Content */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
          <div className="mb-3">
            <span className={`badge ${currentTutorial.published ? 'badge-success' : 'badge-warning'} text-lg px-3 py-1`}>
              {currentTutorial.published ? '✓ Published' : '⏳ Draft'}
            </span>
          </div>
          
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            {currentTutorial.title}
          </h1>
          
          <div className="text-gray-700 text-lg leading-relaxed whitespace-pre-wrap mb-4">
            {currentTutorial.description}
          </div>

          {/* Rating Section */}
          <div className="border-t pt-4 mt-4">
            <h4 className="mb-3 font-bold text-xl">Rating</h4>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex-1">
                <p className="text-sm text-gray-600 mb-2">Average Rating</p>
                <StarRating 
                  rating={ratingStats.averageRating} 
                  readonly={true}
                />
                <p className="text-sm text-gray-500 mt-1">
                  Based on {ratingStats.ratingCount} rating{ratingStats.ratingCount !== 1 ? 's' : ''}
                </p>
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600 mb-2">Rate this tutorial</p>
                <StarRating 
                  rating={userRating} 
                  onRatingChange={this.handleRatingChange}
                  readonly={false}
                />
                {userRating > 0 && (
                  <p className="text-sm text-green-600 mt-1">
                    ✓ You rated this tutorial {userRating} star{userRating !== 1 ? 's' : ''}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Success Message */}
        {message && (
          <div className="alert alert-success" role="alert">
            {message}
          </div>
        )}

        {/* Comments Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <Comments tutorialId={currentTutorial.id} />
        </div>
      </div>
    );
  }
}

export default withRouter(TutorialView);
