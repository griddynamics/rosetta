import React, { Component } from "react";
import TutorialDataService from "../services/tutorial.service";
import { Link } from "react-router-dom";
import StarRating from "./star-rating.component";

class FeaturedTutorials extends Component {
  constructor(props) {
    super(props);
    this.state = {
      topRated: [],
      mostDiscussed: [],
      loading: true
    };
  }

  componentDidMount() {
    this.loadFeaturedTutorials();
  }

  loadFeaturedTutorials() {
    this.setState({ loading: true });
    
    // Load top rated tutorials
    TutorialDataService.getTopRated(1, 5)
      .then(response => {
        this.setState({ topRated: response.data });
      })
      .catch(e => {
        console.log("Error loading top rated:", e);
      });

    // Load most discussed tutorials
    TutorialDataService.getMostDiscussed(5)
      .then(response => {
        this.setState({ 
          mostDiscussed: response.data,
          loading: false
        });
      })
      .catch(e => {
        console.log("Error loading most discussed:", e);
        this.setState({ loading: false });
      });
  }

  render() {
    const { topRated, mostDiscussed, loading } = this.state;

    if (loading) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
          <div className="container mx-auto px-4">
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              <p className="mt-4 text-gray-600">Loading featured tutorials...</p>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
        <div className="container mx-auto px-4">
          {/* Header Section */}
          <div className="mb-8">
            <h2 className="text-4xl font-bold text-gray-800 mb-2">
              ⭐ Featured Tutorials
            </h2>
            <p className="text-gray-600">
              Discover our top-rated and most-discussed tutorials
            </p>
          </div>

          {/* Top Rated Section */}
          <div className="mb-8">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="mb-4 text-2xl font-semibold text-blue-600 flex items-center">
                <span className="mr-2">⭐</span>
                Top Rated Tutorials
              </h3>
              {topRated.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <div className="text-6xl mb-4">⭐</div>
                  <p className="text-gray-500 italic">No rated tutorials yet.</p>
                  <p className="text-gray-400 text-sm mt-2">Be the first to rate a tutorial!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {topRated.map((tutorial) => (
                    <Link 
                      to={`/tutorials/${tutorial.tutorialId}`} 
                      key={tutorial.tutorialId}
                      className="no-underline"
                    >
                      <div className="bg-gradient-to-br from-white to-blue-50 border-2 border-blue-100 rounded-lg p-5 hover:shadow-xl hover:border-blue-300 transition-all duration-200 cursor-pointer h-full">
                        <h5 className="font-bold text-lg mb-3 text-gray-800 line-clamp-2">{tutorial.title}</h5>
                        <div className="flex items-center justify-center mb-3">
                          <StarRating 
                            rating={tutorial.averageRating} 
                            readonly={true}
                            size="text-xl"
                          />
                        </div>
                        <div className="flex items-center justify-between text-sm text-gray-600 pt-3 border-t border-blue-100">
                          <span className="flex items-center gap-1">
                            📊 <span className="font-medium">{tutorial.ratingCount}</span> rating{tutorial.ratingCount !== 1 ? 's' : ''}
                          </span>
                          <span className="flex items-center gap-1">
                            💬 <span className="font-medium">{tutorial.commentCount}</span> comment{tutorial.commentCount !== 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Most Discussed Section */}
          <div className="mb-8">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="mb-4 text-2xl font-semibold text-green-600 flex items-center">
                <span className="mr-2">💬</span>
                Most Discussed Tutorials
              </h3>
              {mostDiscussed.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <div className="text-6xl mb-4">💬</div>
                  <p className="text-gray-500 italic">No discussions yet.</p>
                  <p className="text-gray-400 text-sm mt-2">Start the conversation!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {mostDiscussed.map((tutorial) => (
                    <Link 
                      to={`/tutorials/${tutorial.tutorialId}`} 
                      key={tutorial.tutorialId}
                      className="no-underline"
                    >
                      <div className="bg-gradient-to-br from-white to-green-50 border-2 border-green-100 rounded-lg p-5 hover:shadow-xl hover:border-green-300 transition-all duration-200 cursor-pointer h-full">
                        <h5 className="font-bold text-lg mb-3 text-gray-800 line-clamp-2">{tutorial.title}</h5>
                        <div className="flex items-center justify-center mb-3">
                          <StarRating 
                            rating={tutorial.averageRating} 
                            readonly={true}
                            size="text-xl"
                          />
                        </div>
                        <div className="flex items-center justify-between text-sm text-gray-600 pt-3 border-t border-green-100">
                          <span className="flex items-center gap-1 font-semibold text-green-600">
                            💬 <span className="font-bold">{tutorial.commentCount}</span> comment{tutorial.commentCount !== 1 ? 's' : ''}
                          </span>
                          <span className="flex items-center gap-1">
                            📊 <span className="font-medium">{tutorial.ratingCount}</span> rating{tutorial.ratingCount !== 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* View All Button */}
          <div className="text-center mt-8">
            <Link 
              to="/tutorials" 
              className="inline-block px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl font-semibold text-lg"
            >
              📚 View All Tutorials
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default FeaturedTutorials;
