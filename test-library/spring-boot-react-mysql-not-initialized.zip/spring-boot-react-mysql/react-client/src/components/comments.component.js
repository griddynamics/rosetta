import React, { useState, useEffect } from "react";
import TutorialDataService from "../services/tutorial.service";

const CommentItem = ({ comment, tutorialId, onReply, onDelete, depth = 0 }) => {
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [replyContent, setReplyContent] = useState("");
  const [replyAuthor, setReplyAuthor] = useState("");

  const handleReplySubmit = (e) => {
    e.preventDefault();
    if (replyContent.trim() && replyAuthor.trim()) {
      onReply(tutorialId, replyContent, replyAuthor, comment.id);
      setReplyContent("");
      setReplyAuthor("");
      setShowReplyForm(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  return (
    <div className={`${depth > 0 ? 'ml-8 mt-3' : 'mt-4'} border-l-2 border-gray-200 pl-4`}>
      <div className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <span className="font-semibold text-blue-600">{comment.authorName}</span>
            <span className="text-xs text-gray-500 ml-2">{formatDate(comment.createdAt)}</span>
          </div>
          {onDelete && (
            <button
              onClick={() => onDelete(comment.id)}
              className="text-red-500 hover:text-red-700 text-sm"
            >
              Delete
            </button>
          )}
        </div>
        <p className="text-gray-700 whitespace-pre-wrap">{comment.content}</p>
        
        {depth < 3 && (
          <button
            onClick={() => setShowReplyForm(!showReplyForm)}
            className="text-sm text-blue-500 hover:text-blue-700 mt-2"
          >
            {showReplyForm ? "Cancel" : "Reply"}
          </button>
        )}

        {showReplyForm && (
          <form onSubmit={handleReplySubmit} className="mt-3 bg-gray-50 p-3 rounded">
            <input
              type="text"
              className="form-control mb-2"
              placeholder="Your name"
              value={replyAuthor}
              onChange={(e) => setReplyAuthor(e.target.value)}
              required
            />
            <textarea
              className="form-control mb-2"
              placeholder="Write a reply..."
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              rows="2"
              required
            />
            <button type="submit" className="btn btn-primary btn-sm">
              Post Reply
            </button>
          </form>
        )}
      </div>

      {comment.replies && comment.replies.length > 0 && (
        <div className="mt-2">
          {comment.replies.map((reply) => (
            <CommentItem
              key={reply.id}
              comment={reply}
              tutorialId={tutorialId}
              onReply={onReply}
              onDelete={onDelete}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const Comments = ({ tutorialId }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (tutorialId) {
      loadComments();
    }
  }, [tutorialId]);

  const loadComments = () => {
    setLoading(true);
    TutorialDataService.getComments(tutorialId)
      .then((response) => {
        setComments(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error loading comments:", error);
        setLoading(false);
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newComment.trim() && authorName.trim()) {
      TutorialDataService.createComment(tutorialId, {
        content: newComment,
        authorName: authorName,
        parentId: null
      })
        .then(() => {
          setNewComment("");
          setAuthorName("");
          setMessage("Comment posted successfully!");
          setTimeout(() => setMessage(""), 3000);
          loadComments();
        })
        .catch((error) => {
          console.error("Error posting comment:", error);
          setMessage("Error posting comment");
        });
    }
  };

  const handleReply = (tutorialId, content, author, parentId) => {
    TutorialDataService.createComment(tutorialId, {
      content: content,
      authorName: author,
      parentId: parentId
    })
      .then(() => {
        setMessage("Reply posted successfully!");
        setTimeout(() => setMessage(""), 3000);
        loadComments();
      })
      .catch((error) => {
        console.error("Error posting reply:", error);
        setMessage("Error posting reply");
      });
  };

  const handleDelete = (commentId) => {
    if (window.confirm("Are you sure you want to delete this comment?")) {
      TutorialDataService.deleteComment(commentId)
        .then(() => {
          setMessage("Comment deleted successfully!");
          setTimeout(() => setMessage(""), 3000);
          loadComments();
        })
        .catch((error) => {
          console.error("Error deleting comment:", error);
          setMessage("Error deleting comment");
        });
    }
  };

  return (
    <div className="mt-4">
      <h4 className="mb-3 font-bold text-xl">Comments ({comments.length})</h4>

      {message && (
        <div className="alert alert-info" role="alert">
          {message}
        </div>
      )}

      <form onSubmit={handleSubmit} className="mb-4 bg-gray-50 p-4 rounded-lg">
        <input
          type="text"
          className="form-control mb-2"
          placeholder="Your name"
          value={authorName}
          onChange={(e) => setAuthorName(e.target.value)}
          required
        />
        <textarea
          className="form-control mb-2"
          placeholder="Write a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          rows="3"
          required
        />
        <button type="submit" className="btn btn-primary">
          Post Comment
        </button>
      </form>

      {loading ? (
        <div className="text-center">Loading comments...</div>
      ) : (
        <div>
          {comments.length === 0 ? (
            <p className="text-gray-500 italic">No comments yet. Be the first to comment!</p>
          ) : (
            comments.map((comment) => (
              <CommentItem
                key={comment.id}
                comment={comment}
                tutorialId={tutorialId}
                onReply={handleReply}
                onDelete={handleDelete}
              />
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default Comments;
