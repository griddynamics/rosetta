import React, { Component } from "react";
import TutorialDataService from "../services/tutorial.service";
import { withRouter } from '../common/with-router';
import { Link } from "react-router-dom";
import StarRating from "./star-rating.component";
import Comments from "./comments.component";

class Tutorial extends Component {
  constructor(props) {
    super(props);
    this.onChangeTitle = this.onChangeTitle.bind(this);
    this.onChangeDescription = this.onChangeDescription.bind(this);
    this.getTutorial = this.getTutorial.bind(this);
    this.updatePublished = this.updatePublished.bind(this);
    this.updateTutorial = this.updateTutorial.bind(this);
    this.deleteTutorial = this.deleteTutorial.bind(this);
    this.handleRatingChange = this.handleRatingChange.bind(this);
    this.loadRatingStats = this.loadRatingStats.bind(this);

    this.state = {
      currentTutorial: {
        id: null,
        title: "",
        description: "",
        published: false
      },
      message: "",
      ratingStats: {
        averageRating: 0,
        ratingCount: 0
      },
      userRating: 0,
      username: localStorage.getItem('username') || ''
    };
  }

  componentDidMount() {
    this.getTutorial(this.props.router.params.id);
    this.loadRatingStats(this.props.router.params.id);
  }

  onChangeTitle(e) {
    const title = e.target.value;

    this.setState(function(prevState) {
      return {
        currentTutorial: {
          ...prevState.currentTutorial,
          title: title
        }
      };
    });
  }

  onChangeDescription(e) {
    const description = e.target.value;
    
    this.setState(prevState => ({
      currentTutorial: {
        ...prevState.currentTutorial,
        description: description
      }
    }));
  }

  getTutorial(id) {
    TutorialDataService.get(id)
      .then(response => {
        this.setState({
          currentTutorial: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  updatePublished(status) {
    var data = {
      id: this.state.currentTutorial.id,
      title: this.state.currentTutorial.title,
      description: this.state.currentTutorial.description,
      published: status
    };

    TutorialDataService.update(this.state.currentTutorial.id, data)
      .then(response => {
        this.setState(prevState => ({
          currentTutorial: {
            ...prevState.currentTutorial,
            published: status
          }
        }));
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  updateTutorial() {
    TutorialDataService.update(
      this.state.currentTutorial.id,
      this.state.currentTutorial
    )
      .then(response => {
        console.log(response.data);
        this.setState({
          message: "The tutorial was updated successfully!"
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  deleteTutorial() {    
    TutorialDataService.delete(this.state.currentTutorial.id)
      .then(response => {
        console.log(response.data);
        this.props.router.navigate('/tutorials');
      })
      .catch(e => {
        console.log(e);
      });
  }

  loadRatingStats(tutorialId) {
    TutorialDataService.getRatingStats(tutorialId)
      .then(response => {
        this.setState({
          ratingStats: response.data
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  handleRatingChange(stars) {
    const { username } = this.state;
    if (!username || username.trim() === '') {
      const name = prompt('Please enter your name to rate:');
      if (!name || name.trim() === '') {
        return;
      }
      this.setState({ username: name });
      localStorage.setItem('username', name);
    }

    const userIdentifier = username || localStorage.getItem('username');
    
    TutorialDataService.createOrUpdateRating(this.state.currentTutorial.id, {
      stars: stars,
      userIdentifier: userIdentifier
    })
      .then(() => {
        this.setState({ 
          userRating: stars,
          message: "Rating submitted successfully!"
        });
        setTimeout(() => this.setState({ message: "" }), 3000);
        this.loadRatingStats(this.state.currentTutorial.id);
      })
      .catch(e => {
        console.log(e);
        this.setState({ message: "Error submitting rating" });
      });
  }

  render() {
    const { currentTutorial, ratingStats, userRating, message } = this.state;

    if (!currentTutorial.id) {
      return (
        <div className="container mt-4">
          <div className="alert alert-warning" role="alert">
            Please select a tutorial to edit.
          </div>
        </div>
      );
    }

    return (
      <div className="container mt-4">
        {/* Header with back button */}
        <div className="mb-4">
          <Link to="/tutorials" className="btn btn-outline-secondary">
            ← Back to Tutorials
          </Link>
        </div>

        {/* Tutorial Edit Form */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
          <div className="mb-4">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">
              ✏️ Edit Tutorial
            </h1>
            <p className="text-gray-600">Update tutorial information and settings</p>
          </div>

          {/* Status Badge */}
          <div className="mb-4">
            <span className={`badge ${currentTutorial.published ? 'badge-success' : 'badge-warning'} text-lg px-3 py-1`}>
              {currentTutorial.published ? '✓ Published' : '⏳ Draft'}
            </span>
          </div>

          {/* Form Fields */}
          <form className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-semibold text-gray-700 mb-2">
                Title
              </label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                id="title"
                value={currentTutorial.title}
                onChange={this.onChangeTitle}
              />
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-semibold text-gray-700 mb-2">
                Description
              </label>
              <textarea
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                id="description"
                rows="6"
                value={currentTutorial.description}
                onChange={this.onChangeDescription}
              />
            </div>
          </form>

          {/* Action Buttons */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex flex-wrap gap-3">
              <button
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg font-medium"
                onClick={this.updateTutorial}
              >
                💾 Save Changes
              </button>

              {currentTutorial.published ? (
                <button
                  className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors shadow-md hover:shadow-lg font-medium"
                  onClick={() => this.updatePublished(false)}
                >
                  📝 Unpublish
                </button>
              ) : (
                <button
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors shadow-md hover:shadow-lg font-medium"
                  onClick={() => this.updatePublished(true)}
                >
                  ✓ Publish
                </button>
              )}

              <button
                className="px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors shadow-md hover:shadow-lg font-medium"
                onClick={this.deleteTutorial}
              >
                🗑️ Delete
              </button>
            </div>
          </div>

          {/* Success/Error Message */}
          {message && (
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-green-800 font-medium">{message}</p>
            </div>
          )}
        </div>

        {/* Rating Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
          <h4 className="mb-4 font-bold text-2xl text-gray-800">Rating</h4>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex-1">
              <p className="text-sm text-gray-600 mb-2">Average Rating</p>
              <StarRating 
                rating={ratingStats.averageRating} 
                readonly={true}
              />
              <p className="text-sm text-gray-500 mt-1">
                Based on {ratingStats.ratingCount} rating{ratingStats.ratingCount !== 1 ? 's' : ''}
              </p>
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-600 mb-2">Rate this tutorial</p>
              <StarRating 
                rating={userRating} 
                onRatingChange={this.handleRatingChange}
                readonly={false}
              />
              {userRating > 0 && (
                <p className="text-sm text-green-600 mt-1">
                  ✓ You rated this tutorial {userRating} star{userRating !== 1 ? 's' : ''}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Comments Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <Comments tutorialId={currentTutorial.id} />
        </div>
      </div>
    );
  }
}

export default withRouter(Tutorial);