import React, { Component } from "react";
import TutorialDataService from "../services/tutorial.service";
import { Link } from "react-router-dom";

export default class TutorialsList extends Component {
  constructor(props) {
    super(props);
    this.onChangeSearchTitle = this.onChangeSearchTitle.bind(this);
    this.retrieveTutorials = this.retrieveTutorials.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.setActiveTutorial = this.setActiveTutorial.bind(this);
    this.removeAllTutorials = this.removeAllTutorials.bind(this);
    this.searchTitle = this.searchTitle.bind(this);

    this.state = {
      tutorials: [],
      currentTutorial: null,
      currentIndex: -1,
      searchTitle: "",
      loading: false
    };
  }

  componentDidMount() {
    this.retrieveTutorials();
  }

  onChangeSearchTitle(e) {
    const searchTitle = e.target.value;

    this.setState({
      searchTitle: searchTitle
    });
  }

  retrieveTutorials() {
    this.setState({ loading: true });
    TutorialDataService.getAll()
      .then(response => {
        this.setState({
          tutorials: response.data,
          loading: false
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
        this.setState({ loading: false });
      });
  }

  refreshList() {
    this.retrieveTutorials();
    this.setState({
      currentTutorial: null,
      currentIndex: -1
    });
  }

  setActiveTutorial(tutorial, index) {
    this.setState({
      currentTutorial: tutorial,
      currentIndex: index
    });
  }

  removeAllTutorials() {
    if (window.confirm("Are you sure you want to remove all tutorials? This action cannot be undone.")) {
      TutorialDataService.deleteAll()
        .then(response => {
          console.log(response.data);
          this.refreshList();
        })
        .catch(e => {
          console.log(e);
        });
    }
  }

  searchTitle() {
    this.setState({
      currentTutorial: null,
      currentIndex: -1,
      loading: true
    });

    TutorialDataService.findByTitle(this.state.searchTitle)
      .then(response => {
        this.setState({
          tutorials: response.data,
          loading: false
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
        this.setState({ loading: false });
      });
  }

  render() {
    const { searchTitle, tutorials, currentTutorial, currentIndex, loading } = this.state;

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
        <div className="container mx-auto px-4">
          {/* Header Section */}
          <div className="mb-8">
            <h2 className="text-4xl font-bold text-gray-800 mb-2">
              📚 All Tutorials
            </h2>
            <p className="text-gray-600">
              Browse, search, and manage your tutorial collection
            </p>
          </div>

          {/* Search Bar */}
          <div className="mb-8">
            <div className="max-w-2xl">
              <div className="flex gap-2">
                <input
                  type="text"
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
                  placeholder="🔍 Search tutorials by title..."
                  value={searchTitle}
                  onChange={this.onChangeSearchTitle}
                  onKeyPress={(e) => e.key === 'Enter' && this.searchTitle()}
                />
                <button
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg font-medium"
                  type="button"
                  onClick={this.searchTitle}
                >
                  Search
                </button>
                {searchTitle && (
                  <button
                    className="px-4 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                    type="button"
                    onClick={() => {
                      this.setState({ searchTitle: "" });
                      this.refreshList();
                    }}
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Tutorial List */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-800">
                    Tutorials List
                    <span className="ml-2 text-sm font-normal text-gray-500">
                      ({tutorials.length} {tutorials.length === 1 ? 'tutorial' : 'tutorials'})
                    </span>
                  </h3>
                  {tutorials.length > 0 && (
                    <button
                      className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors shadow-sm text-sm font-medium"
                      onClick={this.removeAllTutorials}
                    >
                      🗑️ Remove All
                    </button>
                  )}
                </div>

                {loading ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                    <p className="mt-4 text-gray-600">Loading tutorials...</p>
                  </div>
                ) : tutorials.length === 0 ? (
                  <div className="text-center py-12 bg-gray-50 rounded-lg">
                    <div className="text-6xl mb-4">📭</div>
                    <p className="text-gray-600 text-lg">No tutorials found</p>
                    <p className="text-gray-500 text-sm mt-2">
                      {searchTitle ? "Try a different search term" : "Create your first tutorial to get started"}
                    </p>
                    <Link
                      to="/add"
                      className="inline-block mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      ➕ Create Tutorial
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {tutorials.map((tutorial, index) => (
                      <div
                        key={index}
                        className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                          index === currentIndex
                            ? "border-blue-500 bg-blue-50 shadow-md"
                            : "border-gray-200 hover:border-blue-300 hover:bg-gray-50"
                        }`}
                        onClick={() => this.setActiveTutorial(tutorial, index)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-800 text-lg">
                              {tutorial.title}
                            </h4>
                            <p className="text-sm text-gray-500 mt-1 line-clamp-1">
                              {tutorial.description}
                            </p>
                          </div>
                          <div className="ml-4 flex items-center gap-2">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-medium ${
                                tutorial.published
                                  ? "bg-green-100 text-green-800"
                                  : "bg-yellow-100 text-yellow-800"
                              }`}
                            >
                              {tutorial.published ? "✓ Published" : "⏳ Draft"}
                            </span>
                            <span className="text-gray-400">→</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right Column - Tutorial Details */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl shadow-lg p-6 sticky top-6">
                {currentTutorial ? (
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-4">
                      Tutorial Details
                    </h3>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
                          Title
                        </label>
                        <p className="mt-1 text-gray-800 font-medium text-lg">
                          {currentTutorial.title}
                        </p>
                      </div>

                      <div>
                        <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
                          Description
                        </label>
                        <p className="mt-1 text-gray-700 leading-relaxed">
                          {currentTutorial.description}
                        </p>
                      </div>

                      <div>
                        <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
                          Status
                        </label>
                        <div className="mt-2">
                          <span
                            className={`inline-block px-4 py-2 rounded-lg text-sm font-medium ${
                              currentTutorial.published
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {currentTutorial.published ? "✓ Published" : "⏳ Draft"}
                          </span>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-gray-200">
                        <div className="flex flex-col gap-3">
                          <Link
                            to={"/tutorials/" + currentTutorial.id}
                            className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg font-medium"
                          >
                            <span>👁️</span>
                            <span>View Tutorial</span>
                          </Link>
                          <Link
                            to={"/tutorials/" + currentTutorial.id + "/edit"}
                            className="flex items-center justify-center gap-2 px-4 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors shadow-md hover:shadow-lg font-medium"
                          >
                            <span>✏️</span>
                            <span>Edit Tutorial</span>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">👆</div>
                    <p className="text-gray-600 font-medium">
                      Select a tutorial
                    </p>
                    <p className="text-gray-500 text-sm mt-2">
                      Click on any tutorial from the list to view details
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
