#!/bin/bash

# Script to populate the Spring Boot Tutorial Management System with sample data
# Usage: ./populate-data.sh [backend_url]
# Default backend_url: http://localhost:8080

BACKEND_URL="${1:-http://localhost:8080}"
API_BASE="$BACKEND_URL/api"

echo "=============================================="
echo "Tutorial Data Population Script"
echo "=============================================="
echo "Backend URL: $BACKEND_URL"
echo ""

# Color codes for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if backend is running
echo "Checking backend availability..."
if ! curl -s "$BACKEND_URL/api/tutorials" > /dev/null; then
    echo -e "${RED}❌ Backend is not accessible at $BACKEND_URL${NC}"
    echo "Please start the backend server first."
    exit 1
fi
echo -e "${GREEN}✓ Backend is accessible${NC}"
echo ""

# Array to store tutorial IDs
declare -a TUTORIAL_IDS

# Function to create a tutorial
create_tutorial() {
    local title="$1"
    local description="$2"
    local published="$3"
    
    echo -e "${BLUE}Creating tutorial: $title${NC}"
    
    response=$(curl -s -X POST "$API_BASE/tutorials" \
        -H "Content-Type: application/json" \
        -d "{
            \"title\": \"$title\",
            \"description\": \"$description\",
            \"published\": $published
        }")
    
    tutorial_id=$(echo "$response" | grep -o '"id":[0-9]*' | grep -o '[0-9]*' | head -1)
    
    if [ -n "$tutorial_id" ]; then
        TUTORIAL_IDS+=("$tutorial_id")
        echo -e "${GREEN}✓ Created tutorial ID: $tutorial_id${NC}"
    else
        echo -e "${RED}✗ Failed to create tutorial${NC}"
    fi
    
    sleep 0.5
}

# Function to add a rating
add_rating() {
    local tutorial_id="$1"
    local stars="$2"
    local user="$3"
    
    curl -s -X POST "$API_BASE/tutorials/$tutorial_id/ratings" \
        -H "Content-Type: application/json" \
        -d "{
            \"stars\": $stars,
            \"userIdentifier\": \"$user\"
        }" > /dev/null
    
    echo -e "${GREEN}  ✓ Added $stars-star rating by $user${NC}"
    sleep 0.3
}

# Function to add a comment
add_comment() {
    local tutorial_id="$1"
    local content="$2"
    local author="$3"
    local parent_id="${4:-null}"
    
    response=$(curl -s -X POST "$API_BASE/tutorials/$tutorial_id/comments" \
        -H "Content-Type: application/json" \
        -d "{
            \"content\": \"$content\",
            \"authorName\": \"$author\",
            \"parentId\": $parent_id
        }")
    
    comment_id=$(echo "$response" | grep -o '"id":[0-9]*' | grep -o '[0-9]*' | head -1)
    
    if [ -n "$comment_id" ]; then
        echo -e "${GREEN}  ✓ Added comment by $author (ID: $comment_id)${NC}"
        echo "$comment_id"
    else
        echo -e "${RED}  ✗ Failed to add comment${NC}"
        echo ""
    fi
    
    sleep 0.3
}

echo "=============================================="
echo "Creating Tutorials"
echo "=============================================="
echo ""

# Tutorial 1: Spring Boot Basics
create_tutorial \
    "Spring Boot REST API Tutorial" \
    "Learn how to build RESTful web services using Spring Boot framework. This comprehensive guide covers controllers, services, repositories, and JPA integration with MySQL database." \
    true

# Tutorial 2: React Fundamentals
create_tutorial \
    "React Components and State Management" \
    "Master React fundamentals including functional components, hooks (useState, useEffect), props, and component lifecycle. Build interactive user interfaces with modern React patterns." \
    true

# Tutorial 3: Full Stack Integration
create_tutorial \
    "Full Stack Development with Spring Boot and React" \
    "Complete guide to building a full-stack application. Learn how to connect React frontend with Spring Boot backend using Axios, handle CORS, and implement CRUD operations seamlessly." \
    true

# Tutorial 4: Database Design
create_tutorial \
    "MySQL Database Design Best Practices" \
    "Understand relational database design principles, normalization, indexing strategies, and query optimization. Includes practical examples with Spring Data JPA and Hibernate." \
    true

# Tutorial 5: Authentication
create_tutorial \
    "JWT Authentication in Spring Boot" \
    "Implement secure authentication and authorization using JSON Web Tokens. Learn about Spring Security, password encryption, token generation, and protected API endpoints." \
    false

# Tutorial 6: Testing
create_tutorial \
    "Unit Testing with JUnit and Mockito" \
    "Write comprehensive unit tests for your Spring Boot application. Master JUnit 5, Mockito for mocking dependencies, and achieve high code coverage with best practices." \
    true

# Tutorial 7: Deployment
create_tutorial \
    "Deploying Spring Boot to AWS" \
    "Step-by-step guide to deploying your Spring Boot application to Amazon Web Services. Covers EC2, RDS, S3, and Elastic Beanstalk deployment strategies." \
    false

# Tutorial 8: Microservices
create_tutorial \
    "Microservices Architecture with Spring Cloud" \
    "Build scalable microservices using Spring Cloud. Learn about service discovery (Eureka), API Gateway, load balancing, circuit breakers, and distributed tracing." \
    true

# Tutorial 9: Docker
create_tutorial \
    "Dockerizing Spring Boot Applications" \
    "Containerize your Spring Boot and React applications using Docker. Create multi-stage builds, docker-compose configurations, and manage container orchestration." \
    true

# Tutorial 10: Performance
create_tutorial \
    "Performance Optimization Techniques" \
    "Optimize your application performance with caching strategies (Redis), database query optimization, connection pooling, and async processing with Spring Boot." \
    false

# Tutorial 11: GraphQL
create_tutorial \
    "GraphQL API with Spring Boot" \
    "Build flexible GraphQL APIs as an alternative to REST. Learn schema definition, resolvers, mutations, subscriptions, and integration with React Apollo Client." \
    true

# Tutorial 12: WebSockets
create_tutorial \
    "Real-time Communication with WebSockets" \
    "Implement real-time features using WebSockets and STOMP protocol. Build chat applications, live notifications, and bidirectional communication between client and server." \
    false

# Tutorial 13: Error Handling
create_tutorial \
    "Advanced Error Handling in Spring Boot" \
    "Master exception handling with @ControllerAdvice, custom exceptions, validation, and user-friendly error responses. Includes frontend error boundary patterns." \
    true

# Tutorial 14: Logging
create_tutorial \
    "Logging and Monitoring Best Practices" \
    "Implement structured logging with SLF4J, Logback, and ELK stack integration. Monitor application health with Spring Boot Actuator and Prometheus." \
    true

# Tutorial 15: CI/CD
create_tutorial \
    "CI/CD Pipeline with GitHub Actions" \
    "Automate your development workflow with continuous integration and deployment. Build, test, and deploy automatically using GitHub Actions and Docker Hub." \
    true

echo ""
echo "=============================================="
echo "Adding Ratings and Comments"
echo "=============================================="
echo ""

# Add ratings and comments to tutorials
if [ ${#TUTORIAL_IDS[@]} -gt 0 ]; then
    
    # Tutorial 1: Spring Boot REST API
    if [ ${#TUTORIAL_IDS[@]} -gt 0 ]; then
        echo -e "${YELLOW}Tutorial 1: Spring Boot REST API${NC}"
        add_rating "${TUTORIAL_IDS[0]}" 5 "john.doe@example.com"
        add_rating "${TUTORIAL_IDS[0]}" 5 "jane.smith@example.com"
        add_rating "${TUTORIAL_IDS[0]}" 4 "bob.wilson@example.com"
        comment1=$(add_comment "${TUTORIAL_IDS[0]}" "Excellent tutorial! Very clear explanations and practical examples." "John Doe")
        add_comment "${TUTORIAL_IDS[0]}" "Thanks for this guide! Helped me build my first REST API." "Jane Smith"
        if [ -n "$comment1" ]; then
            add_comment "${TUTORIAL_IDS[0]}" "Glad you found it helpful! Keep learning!" "Author" "$comment1"
        fi
        echo ""
    fi
    
    # Tutorial 2: React Components
    if [ ${#TUTORIAL_IDS[@]} -gt 1 ]; then
        echo -e "${YELLOW}Tutorial 2: React Components${NC}"
        add_rating "${TUTORIAL_IDS[1]}" 5 "alice.johnson@example.com"
        add_rating "${TUTORIAL_IDS[1]}" 5 "charlie.brown@example.com"
        add_rating "${TUTORIAL_IDS[1]}" 5 "diana.prince@example.com"
        comment2=$(add_comment "${TUTORIAL_IDS[1]}" "Best React tutorial I've found! The hooks examples are perfect." "Alice Johnson")
        add_comment "${TUTORIAL_IDS[1]}" "Finally understand useState and useEffect. Thank you!" "Charlie Brown"
        if [ -n "$comment2" ]; then
            add_comment "${TUTORIAL_IDS[1]}" "Happy to help! Check out the advanced hooks tutorial next." "Author" "$comment2"
        fi
        echo ""
    fi
    
    # Tutorial 3: Full Stack Development
    if [ ${#TUTORIAL_IDS[@]} -gt 2 ]; then
        echo -e "${YELLOW}Tutorial 3: Full Stack Development${NC}"
        add_rating "${TUTORIAL_IDS[2]}" 5 "developer1@example.com"
        add_rating "${TUTORIAL_IDS[2]}" 4 "developer2@example.com"
        add_rating "${TUTORIAL_IDS[2]}" 5 "developer3@example.com"
        add_rating "${TUTORIAL_IDS[2]}" 5 "developer4@example.com"
        comment3=$(add_comment "${TUTORIAL_IDS[2]}" "This tutorial is a game-changer! Covers everything needed for full-stack development." "Developer One")
        add_comment "${TUTORIAL_IDS[2]}" "The CORS configuration section saved me hours of debugging!" "Developer Two"
        comment3_2=$(add_comment "${TUTORIAL_IDS[2]}" "Can you add a section on authentication?" "Developer Three")
        if [ -n "$comment3_2" ]; then
            add_comment "${TUTORIAL_IDS[2]}" "Good suggestion! I'll add a JWT authentication section soon." "Author" "$comment3_2"
        fi
        echo ""
    fi
    
    # Tutorial 4: MySQL Database Design
    if [ ${#TUTORIAL_IDS[@]} -gt 3 ]; then
        echo -e "${YELLOW}Tutorial 4: MySQL Database Design${NC}"
        add_rating "${TUTORIAL_IDS[3]}" 4 "dbadmin@example.com"
        add_rating "${TUTORIAL_IDS[3]}" 5 "backend.dev@example.com"
        add_rating "${TUTORIAL_IDS[3]}" 4 "student1@example.com"
        add_comment "${TUTORIAL_IDS[3]}" "Great overview of database normalization principles!" "DB Admin"
        add_comment "${TUTORIAL_IDS[3]}" "The indexing strategies section is very practical." "Backend Developer"
        echo ""
    fi
    
    # Tutorial 6: Unit Testing
    if [ ${#TUTORIAL_IDS[@]} -gt 5 ]; then
        echo -e "${YELLOW}Tutorial 6: Unit Testing${NC}"
        add_rating "${TUTORIAL_IDS[5]}" 5 "qa.engineer@example.com"
        add_rating "${TUTORIAL_IDS[5]}" 5 "tester1@example.com"
        add_rating "${TUTORIAL_IDS[5]}" 4 "java.dev@example.com"
        comment6=$(add_comment "${TUTORIAL_IDS[5]}" "Finally understand how to properly mock dependencies! Excellent examples." "QA Engineer")
        add_comment "${TUTORIAL_IDS[5]}" "My test coverage went from 30% to 85% after following this guide." "Tester One"
        if [ -n "$comment6" ]; then
            add_comment "${TUTORIAL_IDS[5]}" "That's awesome! Keep up the good work on testing." "Author" "$comment6"
        fi
        echo ""
    fi
    
    # Tutorial 8: Microservices
    if [ ${#TUTORIAL_IDS[@]} -gt 7 ]; then
        echo -e "${YELLOW}Tutorial 8: Microservices Architecture${NC}"
        add_rating "${TUTORIAL_IDS[7]}" 5 "architect@example.com"
        add_rating "${TUTORIAL_IDS[7]}" 4 "senior.dev@example.com"
        add_rating "${TUTORIAL_IDS[7]}" 5 "cloud.engineer@example.com"
        add_comment "${TUTORIAL_IDS[7]}" "Comprehensive guide to microservices! The Spring Cloud examples are spot on." "Solution Architect"
        add_comment "${TUTORIAL_IDS[7]}" "The service discovery and API gateway sections are particularly helpful." "Senior Developer"
        echo ""
    fi
    
    # Tutorial 9: Docker
    if [ ${#TUTORIAL_IDS[@]} -gt 8 ]; then
        echo -e "${YELLOW}Tutorial 9: Dockerizing Applications${NC}"
        add_rating "${TUTORIAL_IDS[8]}" 5 "devops@example.com"
        add_rating "${TUTORIAL_IDS[8]}" 5 "container.fan@example.com"
        add_rating "${TUTORIAL_IDS[8]}" 4 "sysadmin@example.com"
        comment9=$(add_comment "${TUTORIAL_IDS[8]}" "Multi-stage builds explained perfectly! My Docker images are now 60% smaller." "DevOps Engineer")
        add_comment "${TUTORIAL_IDS[8]}" "The docker-compose setup works flawlessly." "Container Enthusiast"
        if [ -n "$comment9" ]; then
            add_comment "${TUTORIAL_IDS[8]}" "Great to hear! Small images = faster deployments :)" "Author" "$comment9"
        fi
        echo ""
    fi
    
    # Tutorial 11: GraphQL
    if [ ${#TUTORIAL_IDS[@]} -gt 10 ]; then
        echo -e "${YELLOW}Tutorial 11: GraphQL API${NC}"
        add_rating "${TUTORIAL_IDS[10]}" 4 "api.developer@example.com"
        add_rating "${TUTORIAL_IDS[10]}" 5 "fullstack@example.com"
        add_comment "${TUTORIAL_IDS[10]}" "GraphQL vs REST comparison is very insightful. Time to migrate some endpoints!" "API Developer"
        add_comment "${TUTORIAL_IDS[10]}" "The Apollo Client integration with React is seamless." "Fullstack Developer"
        echo ""
    fi
    
    # Tutorial 13: Error Handling
    if [ ${#TUTORIAL_IDS[@]} -gt 12 ]; then
        echo -e "${YELLOW}Tutorial 13: Advanced Error Handling${NC}"
        add_rating "${TUTORIAL_IDS[12]}" 5 "code.quality@example.com"
        add_rating "${TUTORIAL_IDS[12]}" 4 "junior.dev@example.com"
        add_comment "${TUTORIAL_IDS[12]}" "The @ControllerAdvice pattern cleaned up my code significantly!" "Code Quality Advocate"
        add_comment "${TUTORIAL_IDS[12]}" "Custom exception examples are exactly what I needed." "Junior Developer"
        echo ""
    fi
    
    # Tutorial 14: Logging
    if [ ${#TUTORIAL_IDS[@]} -gt 13 ]; then
        echo -e "${YELLOW}Tutorial 14: Logging and Monitoring${NC}"
        add_rating "${TUTORIAL_IDS[13]}" 5 "sre@example.com"
        add_rating "${TUTORIAL_IDS[13]}" 5 "monitoring.expert@example.com"
        add_comment "${TUTORIAL_IDS[13]}" "ELK stack integration guide is comprehensive. Our monitoring improved drastically!" "SRE Engineer"
        add_comment "${TUTORIAL_IDS[13]}" "Structured logging with MDC is a game changer for debugging." "Monitoring Expert"
        echo ""
    fi
    
    # Tutorial 15: CI/CD
    if [ ${#TUTORIAL_IDS[@]} -gt 14 ]; then
        echo -e "${YELLOW}Tutorial 15: CI/CD Pipeline${NC}"
        add_rating "${TUTORIAL_IDS[14]}" 5 "devops.lead@example.com"
        add_rating "${TUTORIAL_IDS[14]}" 5 "automation@example.com"
        add_rating "${TUTORIAL_IDS[14]}" 4 "tech.lead@example.com"
        comment15=$(add_comment "${TUTORIAL_IDS[14]}" "GitHub Actions workflow examples are production-ready. Deployed in 30 minutes!" "DevOps Lead")
        add_comment "${TUTORIAL_IDS[14]}" "Automated testing in the pipeline caught several bugs before production." "Automation Engineer"
        if [ -n "$comment15" ]; then
            add_comment "${TUTORIAL_IDS[14]}" "That's the power of CI/CD! Glad it helped." "Author" "$comment15"
        fi
        echo ""
    fi
    
fi

echo "=============================================="
echo "Data Population Summary"
echo "=============================================="
echo -e "${GREEN}✓ Created ${#TUTORIAL_IDS[@]} tutorials${NC}"
echo -e "${GREEN}✓ Added ratings to popular tutorials${NC}"
echo -e "${GREEN}✓ Added comments and threaded replies${NC}"
echo ""
echo "You can now access the application at:"
echo -e "${BLUE}http://localhost:3000${NC}"
echo ""
echo "Tutorial IDs created: ${TUTORIAL_IDS[*]}"
echo ""
echo "=============================================="
echo "Done!"
echo "=============================================="
