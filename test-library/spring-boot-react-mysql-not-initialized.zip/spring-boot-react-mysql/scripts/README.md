# Data Population Script

## Overview

The `populate-data.sh` script automatically populates your Spring Boot Tutorial Management System with sample data including tutorials, ratings, and comments. This is particularly useful when starting with a fresh database or for testing purposes.

## Features

- ✅ Creates **15 diverse tutorials** covering various technical topics
- ✅ Adds **realistic ratings** (1-5 stars) from multiple users
- ✅ Posts **comments and threaded replies** to simulate community engagement
- ✅ Includes tutorials in both **published** and **draft** states
- ✅ Verifies backend availability before starting
- ✅ Provides colored, user-friendly console output
- ✅ Returns summary with tutorial IDs created

## Prerequisites

- Backend server must be running at `http://localhost:8080` (or custom URL)
- `curl` command-line tool must be available
- Bash shell environment (macOS, Linux, WSL on Windows)

## Usage

### Basic Usage (Default Backend URL)

```bash
cd scripts
./populate-data.sh
```

This assumes your backend is running at `http://localhost:8080`.

### Custom Backend URL

If your backend is running on a different host or port:

```bash
./populate-data.sh http://your-backend-url:port
```

For example:
```bash
./populate-data.sh http://localhost:8090
./populate-data.sh http://192.168.1.100:8080
./populate-data.sh https://api.example.com
```

## What Gets Created

### Tutorials (15 total)

1. **Spring Boot REST API Tutorial** (Published)
   - 3 ratings (avg: 4.67 stars)
   - 3 comments with 1 reply

2. **React Components and State Management** (Published)
   - 3 ratings (avg: 5.0 stars)
   - 3 comments with 1 reply

3. **Full Stack Development with Spring Boot and React** (Published)
   - 4 ratings (avg: 4.75 stars)
   - 4 comments with 1 reply

4. **MySQL Database Design Best Practices** (Published)
   - 3 ratings (avg: 4.33 stars)
   - 2 comments

5. **JWT Authentication in Spring Boot** (Draft)
   - No ratings or comments

6. **Unit Testing with JUnit and Mockito** (Published)
   - 3 ratings (avg: 4.67 stars)
   - 3 comments with 1 reply

7. **Deploying Spring Boot to AWS** (Draft)
   - No ratings or comments

8. **Microservices Architecture with Spring Cloud** (Published)
   - 3 ratings (avg: 4.67 stars)
   - 2 comments

9. **Dockerizing Spring Boot Applications** (Published)
   - 3 ratings (avg: 4.67 stars)
   - 3 comments with 1 reply

10. **Performance Optimization Techniques** (Draft)
    - No ratings or comments

11. **GraphQL API with Spring Boot** (Published)
    - 2 ratings (avg: 4.5 stars)
    - 2 comments

12. **Real-time Communication with WebSockets** (Draft)
    - No ratings or comments

13. **Advanced Error Handling in Spring Boot** (Published)
    - 2 ratings (avg: 4.5 stars)
    - 2 comments

14. **Logging and Monitoring Best Practices** (Published)
    - 2 ratings (avg: 5.0 stars)
    - 2 comments

15. **CI/CD Pipeline with GitHub Actions** (Published)
    - 3 ratings (avg: 4.67 stars)
    - 3 comments with 1 reply

### Statistics

- **Total Tutorials**: 15
- **Published**: 11 tutorials
- **Draft**: 4 tutorials
- **Total Ratings**: ~40 ratings
- **Total Comments**: ~30 comments (including replies)
- **Users**: Multiple unique user identifiers

## Script Output

The script provides real-time feedback with color-coded messages:

- 🟢 **Green**: Success messages (tutorials created, ratings added, etc.)
- 🔵 **Blue**: Information messages (creating tutorial...)
- 🟡 **Yellow**: Section headers (Tutorial 1: Spring Boot REST API)
- 🔴 **Red**: Error messages (backend not accessible)

Example output:
```
==============================================
Tutorial Data Population Script
==============================================
Backend URL: http://localhost:8080

Checking backend availability...
✓ Backend is accessible

==============================================
Creating Tutorials
==============================================

Creating tutorial: Spring Boot REST API Tutorial
✓ Created tutorial ID: 1

...

==============================================
Adding Ratings and Comments
==============================================

Tutorial 1: Spring Boot REST API
  ✓ Added 5-star rating by john.doe@example.com
  ✓ Added comment by John Doe (ID: 1)
  
...

==============================================
Data Population Summary
==============================================
✓ Created 15 tutorials
✓ Added ratings to popular tutorials
✓ Added comments and threaded replies

You can now access the application at:
http://localhost:3000

Tutorial IDs created: 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15

==============================================
Done!
==============================================
```

## Testing the Results

After running the script:

1. **Open the application**: Navigate to `http://localhost:3000`

2. **Check Featured Page**: 
   - Click "Featured" to see Top Rated and Most Discussed tutorials
   - Verify tutorials appear with correct ratings and comment counts

3. **Browse All Tutorials**: 
   - Click "Tutorials" to see the complete list
   - Notice published vs. draft status badges
   - Try searching by title

4. **View Tutorial Details**: 
   - Click on any tutorial to view details
   - See ratings and comments
   - Test adding your own rating or comment

## Cleanup

To remove all created data and start fresh:

```bash
# Delete all tutorials (via API)
curl -X DELETE http://localhost:8080/api/tutorials

# Or restart the backend with a fresh H2 database
# (H2 in-memory database is cleared on restart)
```

Then you can run the script again to repopulate.

## Troubleshooting

### Backend Not Accessible

**Error**: `❌ Backend is not accessible at http://localhost:8080`

**Solutions**:
- Verify backend is running: `curl http://localhost:8080/api/tutorials`
- Check backend logs for errors
- Ensure correct backend URL is used
- Check firewall/network settings

### Script Permission Denied

**Error**: `Permission denied: ./populate-data.sh`

**Solution**:
```bash
chmod +x populate-data.sh
```

### Curl Not Found

**Error**: `curl: command not found`

**Solutions**:
- macOS: `brew install curl`
- Ubuntu/Debian: `sudo apt-get install curl`
- CentOS/RHEL: `sudo yum install curl`

### Duplicate Tutorial IDs

If you run the script multiple times without cleanup, tutorial IDs will increment (1-15, then 16-30, etc.). This is normal behavior and won't cause issues.

## Integration with Backend Startup

You can automate data population on backend startup by adding the script to your development workflow:

### Option 1: Maven Profile

Add to `pom.xml`:
```xml
<profile>
    <id>populate-data</id>
    <build>
        <plugins>
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <executions>
                    <execution>
                        <phase>spring-boot:run</phase>
                        <goals>
                            <goal>exec</goal>
                        </goals>
                        <configuration>
                            <executable>bash</executable>
                            <arguments>
                                <argument>${project.basedir}/../scripts/populate-data.sh</argument>
                            </arguments>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</profile>
```

Run with: `mvn spring-boot:run -Ppopulate-data`

### Option 2: Startup Script

Create `start-with-data.sh`:
```bash
#!/bin/bash
cd spring-boot-server
./mvnw spring-boot:run &
BACKEND_PID=$!

# Wait for backend to be ready
sleep 30

# Populate data
cd ../scripts
./populate-data.sh

# Keep backend running
wait $BACKEND_PID
```

### Option 3: Docker Compose

Add to `docker-compose.yml`:
```yaml
services:
  backend:
    # ... backend configuration
  
  data-populator:
    image: curlimages/curl:latest
    depends_on:
      - backend
    command: >
      sh -c "sleep 30 && /scripts/populate-data.sh http://backend:8080"
    volumes:
      - ./scripts:/scripts
```

## Customization

To customize the data:

1. Open `populate-data.sh` in a text editor
2. Modify the `create_tutorial` calls to change tutorial content
3. Adjust `add_rating` and `add_comment` calls to change engagement
4. Add or remove tutorials as needed
5. Change star ratings (1-5) for different average scores

Example:
```bash
create_tutorial \
    "Your Custom Tutorial Title" \
    "Your detailed description here" \
    true  # true = published, false = draft
```

## Support

For issues or questions:
- Check backend logs: `tail -f /tmp/backend.log`
- Verify API endpoints manually with curl
- Review script output for specific error messages
- Ensure all prerequisites are met

## License

This script is part of the Spring Boot React MySQL Tutorial Management System project.
