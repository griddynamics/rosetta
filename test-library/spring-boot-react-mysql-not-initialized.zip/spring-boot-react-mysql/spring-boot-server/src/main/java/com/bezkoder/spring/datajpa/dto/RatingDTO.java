package com.bezkoder.spring.datajpa.dto;

import java.time.LocalDateTime;

public class RatingDTO {
    
    private long id;
    private int stars;
    private String userIdentifier;
    private LocalDateTime createdAt;
    private Long tutorialId;

    public RatingDTO() {
    }

    public RatingDTO(long id, int stars, String userIdentifier, LocalDateTime createdAt, Long tutorialId) {
        this.id = id;
        this.stars = stars;
        this.userIdentifier = userIdentifier;
        this.createdAt = createdAt;
        this.tutorialId = tutorialId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Long getTutorialId() {
        return tutorialId;
    }

    public void setTutorialId(Long tutorialId) {
        this.tutorialId = tutorialId;
    }
}
