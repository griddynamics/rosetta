package com.bezkoder.spring.datajpa.repository;

import com.bezkoder.spring.datajpa.model.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface RatingRepository extends JpaRepository<Rating, Long> {
    
    // Find all ratings for a tutorial
    List<Rating> findByTutorialId(Long tutorialId);
    
    // Find a user's rating for a specific tutorial
    Optional<Rating> findByTutorialIdAndUserIdentifier(Long tutorialId, String userIdentifier);
    
    // Calculate average rating for a tutorial
    @Query("SELECT AVG(r.stars) FROM Rating r WHERE r.tutorial.id = :tutorialId")
    Double findAverageRatingByTutorialId(Long tutorialId);
    
    // Count ratings for a tutorial
    long countByTutorialId(Long tutorialId);
    
    // Find tutorials with highest average ratings (for "Top Rated")
    @Query("SELECT r.tutorial.id, AVG(r.stars) as avgRating, COUNT(r) as ratingCount " +
           "FROM Rating r " +
           "GROUP BY r.tutorial.id " +
           "HAVING COUNT(r) >= :minRatings " +
           "ORDER BY avgRating DESC, ratingCount DESC")
    List<Object[]> findTopRatedTutorials(long minRatings);
}
