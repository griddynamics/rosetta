package com.bezkoder.spring.datajpa.repository;

import com.bezkoder.spring.datajpa.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    
    // Find all top-level comments (no parent) for a tutorial
    List<Comment> findByTutorialIdAndParentIsNull(Long tutorialId);
    
    // Find all comments for a tutorial (including replies)
    List<Comment> findByTutorialId(Long tutorialId);
    
    // Find replies for a specific comment
    List<Comment> findByParentId(Long parentId);
    
    // Count comments for a tutorial
    long countByTutorialId(Long tutorialId);
    
    // Find tutorials with most comments (for "Most Discussed")
    @Query("SELECT c.tutorial.id, COUNT(c) as commentCount FROM Comment c GROUP BY c.tutorial.id ORDER BY commentCount DESC")
    List<Object[]> findTutorialsWithMostComments();
}
