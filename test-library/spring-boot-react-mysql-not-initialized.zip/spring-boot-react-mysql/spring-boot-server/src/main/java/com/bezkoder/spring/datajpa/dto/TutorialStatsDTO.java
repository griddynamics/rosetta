package com.bezkoder.spring.datajpa.dto;

public class TutorialStatsDTO {
    
    private long tutorialId;
    private String title;
    private double averageRating;
    private long ratingCount;
    private long commentCount;

    public TutorialStatsDTO() {
    }

    public TutorialStatsDTO(long tutorialId, String title, double averageRating, long ratingCount, long commentCount) {
        this.tutorialId = tutorialId;
        this.title = title;
        this.averageRating = averageRating;
        this.ratingCount = ratingCount;
        this.commentCount = commentCount;
    }

    public long getTutorialId() {
        return tutorialId;
    }

    public void setTutorialId(long tutorialId) {
        this.tutorialId = tutorialId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(double averageRating) {
        this.averageRating = averageRating;
    }

    public long getRatingCount() {
        return ratingCount;
    }

    public void setRatingCount(long ratingCount) {
        this.ratingCount = ratingCount;
    }

    public long getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(long commentCount) {
        this.commentCount = commentCount;
    }
}
