package com.bezkoder.spring.datajpa.controller;

import com.bezkoder.spring.datajpa.dto.CommentDTO;
import com.bezkoder.spring.datajpa.dto.CreateCommentRequest;
import com.bezkoder.spring.datajpa.model.Comment;
import com.bezkoder.spring.datajpa.model.Tutorial;
import com.bezkoder.spring.datajpa.repository.CommentRepository;
import com.bezkoder.spring.datajpa.repository.TutorialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8081"})
@RestController
@RequestMapping("/api")
public class CommentController {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private TutorialRepository tutorialRepository;

    // Get all comments for a tutorial (with threading)
    @GetMapping("/tutorials/{tutorialId}/comments")
    public ResponseEntity<List<CommentDTO>> getCommentsByTutorialId(@PathVariable("tutorialId") long tutorialId) {
        try {
            List<Comment> topLevelComments = commentRepository.findByTutorialIdAndParentIsNull(tutorialId);
            List<CommentDTO> commentDTOs = topLevelComments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
            return new ResponseEntity<>(commentDTOs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Create a new comment or reply
    @PostMapping("/tutorials/{tutorialId}/comments")
    public ResponseEntity<CommentDTO> createComment(
            @PathVariable("tutorialId") long tutorialId,
            @RequestBody CreateCommentRequest request) {
        try {
            Tutorial tutorial = tutorialRepository.findById(tutorialId)
                .orElseThrow(() -> new RuntimeException("Tutorial not found"));

            Comment comment = new Comment();
            comment.setContent(request.getContent());
            comment.setAuthorName(request.getAuthorName());
            comment.setTutorial(tutorial);

            // Handle reply (parent comment)
            if (request.getParentId() != null) {
                Comment parent = commentRepository.findById(request.getParentId())
                    .orElseThrow(() -> new RuntimeException("Parent comment not found"));
                comment.setParent(parent);
            }

            Comment savedComment = commentRepository.save(comment);
            return new ResponseEntity<>(convertToDTO(savedComment), HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Delete a comment
    @DeleteMapping("/comments/{id}")
    public ResponseEntity<HttpStatus> deleteComment(@PathVariable("id") long id) {
        try {
            commentRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get comment count for a tutorial
    @GetMapping("/tutorials/{tutorialId}/comments/count")
    public ResponseEntity<Map<String, Long>> getCommentCount(@PathVariable("tutorialId") long tutorialId) {
        try {
            long count = commentRepository.countByTutorialId(tutorialId);
            Map<String, Long> response = new HashMap<>();
            response.put("count", count);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Helper method to convert Comment entity to DTO with replies
    private CommentDTO convertToDTO(Comment comment) {
        CommentDTO dto = new CommentDTO();
        dto.setId(comment.getId());
        dto.setContent(comment.getContent());
        dto.setAuthorName(comment.getAuthorName());
        dto.setCreatedAt(comment.getCreatedAt());
        dto.setTutorialId(comment.getTutorial().getId());
        dto.setParentId(comment.getParent() != null ? comment.getParent().getId() : null);

        // Recursively convert replies
        List<CommentDTO> replyDTOs = comment.getReplies().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
        dto.setReplies(replyDTOs);

        return dto;
    }
}
