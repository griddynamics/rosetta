package com.bezkoder.spring.datajpa.dto;

public class CreateCommentRequest {
    
    private String content;
    private String authorName;
    private Long parentId; // null for top-level comments

    public CreateCommentRequest() {
    }

    public CreateCommentRequest(String content, String authorName, Long parentId) {
        this.content = content;
        this.authorName = authorName;
        this.parentId = parentId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }
}
