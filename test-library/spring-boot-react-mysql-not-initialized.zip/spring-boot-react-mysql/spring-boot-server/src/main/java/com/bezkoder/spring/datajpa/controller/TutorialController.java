package com.bezkoder.spring.datajpa.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.spring.datajpa.model.Tutorial;
import com.bezkoder.spring.datajpa.repository.TutorialRepository;
import com.bezkoder.spring.datajpa.repository.RatingRepository;
import com.bezkoder.spring.datajpa.repository.CommentRepository;
import com.bezkoder.spring.datajpa.dto.TutorialStatsDTO;

@CrossOrigin(origins = {"http://localhost:8081", "http://localhost:3000"})
@RestController
@RequestMapping("/api")
public class TutorialController {

	@Autowired
	TutorialRepository tutorialRepository;

	@Autowired
	RatingRepository ratingRepository;

	@Autowired
	CommentRepository commentRepository;

	@GetMapping("/tutorials")
	public ResponseEntity<List<Tutorial>> getAllTutorials(@RequestParam(required = false) String title) {
		try {
			List<Tutorial> tutorials = new ArrayList<Tutorial>();

			if (title == null)
				tutorialRepository.findAll().forEach(tutorials::add);
			else
				tutorialRepository.findByTitleContaining(title).forEach(tutorials::add);

			if (tutorials.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			return new ResponseEntity<>(tutorials, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/tutorials/{id}")
	public ResponseEntity<Tutorial> getTutorialById(@PathVariable("id") long id) {
		Optional<Tutorial> tutorialData = tutorialRepository.findById(id);

		if (tutorialData.isPresent()) {
			return new ResponseEntity<>(tutorialData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/tutorials")
	public ResponseEntity<Tutorial> createTutorial(@RequestBody Tutorial tutorial) {
		try {
			Tutorial _tutorial = tutorialRepository
					.save(new Tutorial(tutorial.getTitle(), tutorial.getDescription(), false));
			return new ResponseEntity<>(_tutorial, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/tutorials/{id}")
	public ResponseEntity<Tutorial> updateTutorial(@PathVariable("id") long id, @RequestBody Tutorial tutorial) {
		Optional<Tutorial> tutorialData = tutorialRepository.findById(id);

		if (tutorialData.isPresent()) {
			Tutorial _tutorial = tutorialData.get();
			_tutorial.setTitle(tutorial.getTitle());
			_tutorial.setDescription(tutorial.getDescription());
			_tutorial.setPublished(tutorial.isPublished());
			return new ResponseEntity<>(tutorialRepository.save(_tutorial), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/tutorials/{id}")
	public ResponseEntity<HttpStatus> deleteTutorial(@PathVariable("id") long id) {
		try {
			tutorialRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/tutorials")
	public ResponseEntity<HttpStatus> deleteAllTutorials() {
		try {
			tutorialRepository.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("/tutorials/published")
	public ResponseEntity<List<Tutorial>> findByPublished() {
		try {
			List<Tutorial> tutorials = tutorialRepository.findByPublished(true);

			if (tutorials.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(tutorials, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/tutorials/top-rated")
	public ResponseEntity<List<TutorialStatsDTO>> getTopRatedTutorials(
			@RequestParam(defaultValue = "1") long minRatings,
			@RequestParam(defaultValue = "10") int limit) {
		try {
			List<Object[]> results = ratingRepository.findTopRatedTutorials(minRatings);
			List<TutorialStatsDTO> topRated = new ArrayList<>();

			int count = 0;
			for (Object[] result : results) {
				if (count >= limit) break;
				
				Long tutorialId = ((Number) result[0]).longValue();
				Double avgRating = ((Number) result[1]).doubleValue();
				Long ratingCount = ((Number) result[2]).longValue();

				Optional<Tutorial> tutorial = tutorialRepository.findById(tutorialId);
				if (tutorial.isPresent()) {
					long commentCount = commentRepository.countByTutorialId(tutorialId);
					TutorialStatsDTO dto = new TutorialStatsDTO(
						tutorialId,
						tutorial.get().getTitle(),
						avgRating,
						ratingCount,
						commentCount
					);
					topRated.add(dto);
					count++;
				}
			}

			if (topRated.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(topRated, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/tutorials/most-discussed")
	public ResponseEntity<List<TutorialStatsDTO>> getMostDiscussedTutorials(
			@RequestParam(defaultValue = "10") int limit) {
		try {
			List<Object[]> results = commentRepository.findTutorialsWithMostComments();
			List<TutorialStatsDTO> mostDiscussed = new ArrayList<>();

			int count = 0;
			for (Object[] result : results) {
				if (count >= limit) break;
				
				Long tutorialId = ((Number) result[0]).longValue();
				Long commentCount = ((Number) result[1]).longValue();

				Optional<Tutorial> tutorial = tutorialRepository.findById(tutorialId);
				if (tutorial.isPresent()) {
					Double avgRating = ratingRepository.findAverageRatingByTutorialId(tutorialId);
					long ratingCount = ratingRepository.countByTutorialId(tutorialId);
					
					TutorialStatsDTO dto = new TutorialStatsDTO(
						tutorialId,
						tutorial.get().getTitle(),
						avgRating != null ? avgRating : 0.0,
						ratingCount,
						commentCount
					);
					mostDiscussed.add(dto);
					count++;
				}
			}

			if (mostDiscussed.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(mostDiscussed, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
