package com.bezkoder.spring.datajpa.controller;

import com.bezkoder.spring.datajpa.dto.CreateRatingRequest;
import com.bezkoder.spring.datajpa.dto.RatingDTO;
import com.bezkoder.spring.datajpa.model.Rating;
import com.bezkoder.spring.datajpa.model.Tutorial;
import com.bezkoder.spring.datajpa.repository.RatingRepository;
import com.bezkoder.spring.datajpa.repository.TutorialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8081"})
@RestController
@RequestMapping("/api")
public class RatingController {

    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private TutorialRepository tutorialRepository;

    // Submit or update a rating
    @PostMapping("/tutorials/{tutorialId}/ratings")
    public ResponseEntity<RatingDTO> createOrUpdateRating(
            @PathVariable("tutorialId") long tutorialId,
            @RequestBody CreateRatingRequest request) {
        try {
            if (request.getStars() < 1 || request.getStars() > 5) {
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }

            Tutorial tutorial = tutorialRepository.findById(tutorialId)
                .orElseThrow(() -> new RuntimeException("Tutorial not found"));

            // Check if user already rated this tutorial
            Optional<Rating> existingRating = ratingRepository
                .findByTutorialIdAndUserIdentifier(tutorialId, request.getUserIdentifier());

            Rating rating;
            if (existingRating.isPresent()) {
                // Update existing rating
                rating = existingRating.get();
                rating.setStars(request.getStars());
            } else {
                // Create new rating
                rating = new Rating();
                rating.setStars(request.getStars());
                rating.setUserIdentifier(request.getUserIdentifier());
                rating.setTutorial(tutorial);
            }

            Rating savedRating = ratingRepository.save(rating);
            return new ResponseEntity<>(convertToDTO(savedRating), HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get all ratings for a tutorial
    @GetMapping("/tutorials/{tutorialId}/ratings")
    public ResponseEntity<List<RatingDTO>> getRatingsByTutorialId(@PathVariable("tutorialId") long tutorialId) {
        try {
            List<Rating> ratings = ratingRepository.findByTutorialId(tutorialId);
            List<RatingDTO> ratingDTOs = ratings.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
            return new ResponseEntity<>(ratingDTOs, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get rating statistics for a tutorial
    @GetMapping("/tutorials/{tutorialId}/ratings/stats")
    public ResponseEntity<Map<String, Object>> getRatingStats(@PathVariable("tutorialId") long tutorialId) {
        try {
            Double avgRating = ratingRepository.findAverageRatingByTutorialId(tutorialId);
            long ratingCount = ratingRepository.countByTutorialId(tutorialId);

            Map<String, Object> stats = new HashMap<>();
            stats.put("averageRating", avgRating != null ? avgRating : 0.0);
            stats.put("ratingCount", ratingCount);

            return new ResponseEntity<>(stats, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get user's rating for a tutorial
    @GetMapping("/tutorials/{tutorialId}/ratings/user/{userIdentifier}")
    public ResponseEntity<RatingDTO> getUserRating(
            @PathVariable("tutorialId") long tutorialId,
            @PathVariable("userIdentifier") String userIdentifier) {
        try {
            Optional<Rating> rating = ratingRepository
                .findByTutorialIdAndUserIdentifier(tutorialId, userIdentifier);
            
            if (rating.isPresent()) {
                return new ResponseEntity<>(convertToDTO(rating.get()), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Delete a rating
    @DeleteMapping("/ratings/{id}")
    public ResponseEntity<HttpStatus> deleteRating(@PathVariable("id") long id) {
        try {
            ratingRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Helper method to convert Rating entity to DTO
    private RatingDTO convertToDTO(Rating rating) {
        RatingDTO dto = new RatingDTO();
        dto.setId(rating.getId());
        dto.setStars(rating.getStars());
        dto.setUserIdentifier(rating.getUserIdentifier());
        dto.setCreatedAt(rating.getCreatedAt());
        dto.setTutorialId(rating.getTutorial().getId());
        return dto;
    }
}
