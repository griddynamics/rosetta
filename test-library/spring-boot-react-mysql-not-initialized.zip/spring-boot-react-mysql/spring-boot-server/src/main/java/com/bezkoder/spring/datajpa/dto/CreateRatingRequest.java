package com.bezkoder.spring.datajpa.dto;

public class CreateRatingRequest {
    
    private int stars; // 1-5
    private String userIdentifier; // Username or email

    public CreateRatingRequest() {
    }

    public CreateRatingRequest(int stars, String userIdentifier) {
        this.stars = stars;
        this.userIdentifier = userIdentifier;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }
}
