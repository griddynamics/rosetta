#!/usr/bin/env bash
# codemap-gen.sh — enumerate repo tree 3-4 levels deep, immediate children only,
# excluding noise dirs/files and top-level .gitignore patterns.
# No git repo present, so this uses find/ls instead of `git ls-files`.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

MAX_DEPTH=4

# Hardcoded noise (always excluded regardless of .gitignore).
HARDCODED_NOISE=(target node_modules build .git .DS_Store dist coverage)

# Extract directory/file-name patterns from the top-level .gitignore
# (strip comments, blank lines, negations, leading/trailing slashes, globs kept as-is).
GITIGNORE_NOISE=()
if [ -f .gitignore ]; then
  while IFS= read -r line; do
    line="${line%%#*}"                 # drop inline comments
    line="$(echo "$line" | xargs)"      # trim whitespace
    [ -z "$line" ] && continue
    [[ "$line" == \!* ]] && continue    # skip negation patterns
    line="${line#/}"
    line="${line%/}"
    [ -z "$line" ] && continue
    GITIGNORE_NOISE+=("$line")
  done < .gitignore
fi

ALL_NOISE=("${HARDCODED_NOISE[@]}" "${GITIGNORE_NOISE[@]}")

# Build a `find` prune expression: -name <pat1> -o -name <pat2> -o ...
PRUNE_EXPR=()
for pat in "${ALL_NOISE[@]}"; do
  if [ ${#PRUNE_EXPR[@]} -gt 0 ]; then
    PRUNE_EXPR+=(-o)
  fi
  PRUNE_EXPR+=(-name "$pat")
done

find . -maxdepth "$MAX_DEPTH" \( "${PRUNE_EXPR[@]}" \) -prune -o -print | sort
