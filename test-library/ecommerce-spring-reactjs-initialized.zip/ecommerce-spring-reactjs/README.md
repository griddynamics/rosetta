# Ecommerce (Spring Boot + React)

Perfume storefront: Spring Boot backend (REST + GraphQL, PostgreSQL, Flyway) and a React/TypeScript frontend (Redux Toolkit, Ant Design). See `docs/CONTEXT.md` for business context and `docs/ARCHITECTURE.md` for technical architecture.

## Prerequisites

- Java 8, Maven (or the bundled `./mvnw`)
- Node.js + npm
- PostgreSQL database named `perfume`

## Backend

```
./mvnw spring-boot:run
```

Configure `src/main/resources/application.properties` for your local datasource, mail, OAuth2, and AWS settings — see `docs/TODO.md` for a required credential-hardening action item before committing any config with real secrets.

## Frontend

```
cd frontend
npm install
npm start
```

## Docs

- `docs/CONTEXT.md` — business context
- `docs/ARCHITECTURE.md` — technical architecture
- `docs/TECHSTACK.md`, `docs/CODEMAP.md`, `docs/DEPENDENCIES.md` — stack, structure, dependencies
- `docs/PATTERNS/` — reusable code patterns
- `docs/ASSUMPTIONS.md`, `docs/TODO.md` — open unknowns and follow-ups
