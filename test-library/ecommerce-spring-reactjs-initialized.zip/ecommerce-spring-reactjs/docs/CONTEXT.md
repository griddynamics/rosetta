# Business Context

This document is the business-and-behavior reference for the workspace. It states what the product is,
who uses it, what the domain covers, and the intended behavior — in business terms only, with no
technical detail. Read it first to understand purpose and scope before reading architecture or code docs.

## Product

- An online storefront that sells perfumes and fragrances to consumers.
- Shoppers browse a fragrance catalog, search and filter it, add items to a cart, and place orders.
- Registered shoppers manage a personal account and see their own order history.
- Staff manage the catalog, orders, and customer records through an administrative area.

## Actors

- Guest: an unauthenticated visitor. Browses and searches the catalog, views product detail and reviews,
  builds a cart, and can register or sign in.
- Customer (registered shopper): an authenticated account holder. Owns a profile and shipping details,
  places orders, views personal order history, updates account information, changes password, and submits
  product reviews and ratings.
- Administrator: a privileged staff user. Manages the catalog and reviews orders and customer records.

## Domain

### Catalog

- Each perfume carries a title, brand/house, perfumer, release year, country of origin, target gender,
  fragrance notes (top, middle, base), description, image, price, volume, product type, and an aggregate rating.
- Shoppers view the full catalog, open a single product for full detail, and view arbitrary sets of products.

### Search and filtering

- Shoppers find products by free-text search, by multi-criteria filters, by target gender, and by perfumer.
- Catalog and search results are presented in pages.

### Cart

- Shoppers add and remove products, set quantities, and see a running total before ordering.
- The cart is retained across the shopping session.

### Checkout and orders

- Placing an order captures the recipient's shipping details: first and last name, city, address, email,
  phone number, and postal index.
- An order records its line items (product, quantity, per-line amount), a total price, and an order date.
- On successful order placement the system sends an order confirmation by email.

### Reviews and ratings

- Shoppers submit a review for a product with an author name, message, and numeric rating.
- Reviews are shown on the product; new reviews appear to others viewing the same product in real time.
- Product ratings aggregate from submitted reviews.

### User accounts and authentication

- Registration requires a human-verification (captcha) check and is confirmed through an email activation link.
- Shoppers sign in with email and password, or through a social-login provider (Google, Facebook, GitHub).
- Shoppers who forget a password request a reset code by email and set a new password.
- Authenticated shoppers view and update their profile and change their password.

### Administration

- Administrators add, edit, and remove perfumes in the catalog, including product images.
- Administrators view all orders, view a specific customer's orders, and remove orders.
- Administrators view all customers and open an individual customer record.

### Notifications

- The system emails customers for account activation, password reset, and order confirmation.

## Target behavior

- Anyone can browse, search, and build a cart without an account.
- Only verified, active accounts can sign in and use account features.
- Each shopper sees only their own orders and profile; administrators see all orders and customers.
- Catalog changes made by administrators are immediately reflected to shoppers.

## Feature context index

- No per-feature context files were split out; all business context fits in this document.

MUST USE SKILL `large-workspace-handling` when working across this codebase (284+ source files).
MUST USE SKILL `codemap` (docs/CODEMAP.md) for code navigation — no LSP/Graphify/GitNexus backend was installed for this workspace.
