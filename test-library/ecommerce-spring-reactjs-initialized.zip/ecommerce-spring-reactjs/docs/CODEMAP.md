# Code Map

Workspace-relative paths. Header = path + recursive children count + short description. Files listed under each header are immediate children only; child directories are covered by their own header where within depth.

## `.` (871 items) — repo root, backend Maven project

- .gitattributes
- .gitignore
- gain.json
- LICENSE
- lombok.config
- mvnw
- mvnw.cmd
- pom.xml

## `src/main/java/com/gmail/merikbest2015/ecommerce` (112 items) — backend Java package root

- EcommerceApplication.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/aspect` (2 items) — AOP logging aspect

- ControllerAspect.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/configuration` (7 items) — Spring bean and app configuration

- ApplicationConfiguration.java
- EmailConfiguration.java
- MvcConfiguration.java
- SwaggerConfiguration.java
- WebSecurityConfiguration.java
- WebSocketConfiguration.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/constants` (3 items) — shared constant values

- ErrorMessage.java
- PathConstants.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/controller` (8 items) — REST controllers

- AdminController.java
- AuthenticationController.java
- OrderController.java
- PerfumeController.java
- RegistrationController.java
- ReviewController.java
- UserController.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/domain` (6 items) — JPA entities

- Order.java
- OrderItem.java
- Perfume.java
- Review.java
- User.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/dto` (26 items) — request/response DTOs

- CaptchaResponse.java
- GraphQLRequest.java
- HeaderResponse.java
- PasswordResetRequest.java
- RegistrationRequest.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/enums` (4 items) — domain enumerations

- AuthProvider.java
- Role.java
- SearchPerfume.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/exception` (8 items) — custom exceptions and handler

- ApiExceptionHandler.java
- ApiRequestException.java
- CaptchaException.java
- EmailException.java
- InputFieldException.java
- PasswordConfirmationException.java
- PasswordException.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/mapper` (7 items) — entity/DTO mappers

- AuthenticationMapper.java
- CommonMapper.java
- OrderMapper.java
- PerfumeMapper.java
- ReviewMapper.java
- UserMapper.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/repository` (8 items) — Spring Data JPA repositories

- OrderItemRepository.java
- OrderRepository.java
- PerfumeRepository.java
- ReviewRepository.java
- UserRepository.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/security` (15 items) — JWT auth and security config

- JwtAuthenticationException.java
- JwtConfigurer.java
- JwtFilter.java
- JwtProvider.java
- UserDetailsServiceImpl.java
- UserPrincipal.java

## `src/main/java/com/gmail/merikbest2015/ecommerce/service` (16 items) — business service interfaces

- AuthenticationService.java
- OrderService.java
- PerfumeService.java
- ReviewService.java
- UserService.java

## `src/main/resources` (17 items) — backend config and static assets

- application.properties

## `src/main/resources/db` (6 items) — Flyway migration scripts holder

(no direct files; migration SQL scripts are under `migration`)

## `src/main/resources/db/migration` (4 items) — Flyway versioned SQL migrations

- V1__Init_BD.sql
- V2__Add_users.sql
- V3__Add_products.sql
- V4__Add_orders.sql

## `src/main/resources/graphql` (2 items) — GraphQL schema

- schemas.graphql

## `src/main/resources/mail-templates` (4 items) — Thymeleaf email templates

- order-template.html
- password-reset-template.html
- registration-template.html

## `src/main/resources/static` (3 items) — static web assets (Swagger UI spec)

(no direct files; spec is under `swagger-api`)

## `src/main/resources/static/swagger-api` (1 items) — Swagger/OpenAPI spec file

- swagger.yaml

## `src/test/java/com/gmail/merikbest2015/ecommerce` (23 items) — backend test package root

- EcommerceApplicationTests.java

## `src/test/java/com/gmail/merikbest2015/ecommerce/controller` (8 items) — controller integration tests

- AdminControllerTest.java
- AuthenticationControllerTest.java
- OrderControllerTest.java
- PerfumeControllerTest.java
- RegistrationControllerTest.java
- ReviewControllerTest.java
- UserControllerTest.java

## `src/test/java/com/gmail/merikbest2015/ecommerce/mapper` (4 items) — mapper unit tests

- OrderMapperTest.java
- PerfumeMapperTest.java
- UserMapperTest.java

## `src/test/java/com/gmail/merikbest2015/ecommerce/service` (7 items) — service unit tests

(no direct files; impl tests are under `Impl`)

## `src/test/java/com/gmail/merikbest2015/ecommerce/util` (2 items) — shared test constants

- TestConstants.java

## `src/test/resources` (10 items) — backend test fixtures

- application-test.properties
- empty.jpg

## `frontend` (352 items) — React/TypeScript frontend app

- .env
- .gitignore
- .prettierrc
- jest.config.js
- package-lock.json
- package.json
- tsconfig.json

## `frontend/public` (2 items) — CRA public assets

- index.html

## `frontend/src` (342 items) — frontend app source

- App.css
- App.tsx
- index.tsx
- react-app-env.d.ts
- setupTests.js
- store.ts

## `frontend/src/components` (56 items) — reusable UI components, each with `__tests__`

(no direct files; see component subdirectories below)

## `frontend/src/components/AccountDataItem` (2 items) — labeled account data row

- AccountDataItem.tsx

## `frontend/src/components/ContentTitle` (3 items) — page section title

- ContentTitle.css
- ContentTitle.tsx

## `frontend/src/components/ContentWrapper` (3 items) — page content layout wrapper

- ContentWrapper.css
- ContentWrapper.tsx

## `frontend/src/components/Footer` (3 items) — site footer

- Footer.scss
- Footer.tsx

## `frontend/src/components/FormInput` (3 items) — controlled form input

- FormInput.css
- FormInput.tsx

## `frontend/src/components/IconButton` (2 items) — icon-only button

- IconButton.tsx

## `frontend/src/components/InputSearch` (2 items) — search input control

- InputSearch.tsx

## `frontend/src/components/NavBar` (3 items) — top navigation bar

- NavBar.scss
- NavBar.tsx

## `frontend/src/components/OrdersTable` (2 items) — orders data table

- OrdersTable.tsx

## `frontend/src/components/PerfumeCard` (3 items) — product card

- PerfumeCard.css
- PerfumeCard.tsx

## `frontend/src/components/SelectSearchData` (2 items) — searchable select control

- SelectSearchData.tsx

## `frontend/src/components/Spinner` (3 items) — loading spinner

- Spinner.css
- Spinner.tsx

## `frontend/src/constants` (3 items) — route and URL constants

- routeConstants.ts
- urlConstants.ts

## `frontend/src/hooks` (5 items) — custom React hooks

- useCart.ts
- usePagination.ts
- useSearch.ts
- useTablePagination.ts

## `frontend/src/img` (5 items) — static image assets

- facebook.png
- github.png
- google.png
- star-half.svg

## `frontend/src/pages` (200 items) — route-level page components

(no direct files; see page subdirectories below)

## `frontend/src/pages/Account` (14 items) — authenticated account area (admin + user subviews)

- Account.tsx

## `frontend/src/pages/Cart` (5 items) — shopping cart page

- Cart.css
- Cart.tsx
- CartTotalPrice.tsx

## `frontend/src/pages/Contacts` (2 items) — contacts page

- Contacts.tsx

## `frontend/src/pages/ForgotPassword` (2 items) — forgot-password page

- ForgotPassword.tsx

## `frontend/src/pages/Home` (6 items) — landing/home page

- Home.tsx

## `frontend/src/pages/Login` (4 items) — login page

- Login.css
- Login.tsx

## `frontend/src/pages/Menu` (6 items) — product catalog/menu page

- Menu.css
- Menu.tsx
- MenuData.ts

## `frontend/src/pages/Order` (3 items) — single order detail page

- Order.tsx

## `frontend/src/pages/OrderFinalize` (2 items) — order finalize/confirmation page

- OrderFinalize.tsx

## `frontend/src/pages/Product` (6 items) — product detail page

- Product.css
- Product.tsx

## `frontend/src/pages/Registration` (2 items) — registration page

- Registration.tsx

## `frontend/src/pages/ResetPassword` (2 items) — reset-password page

- ResetPassword.tsx

## `frontend/src/redux-toolkit` (49 items) — Redux Toolkit slices, one folder per domain

(no direct files; see slice subdirectories below)

## `frontend/src/redux-toolkit/admin` (4 items) — admin slice (selector, slice, thunks)

- admin-selector.ts
- admin-slice.ts
- admin-thunks.ts

## `frontend/src/redux-toolkit/auth` (4 items) — auth slice

- auth-selector.ts
- auth-slice.ts
- auth-thunks.ts

## `frontend/src/redux-toolkit/cart` (4 items) — cart slice

- cart-selector.ts
- cart-slice.ts
- cart-thunks.ts

## `frontend/src/redux-toolkit/order` (4 items) — single order slice

- order-selector.ts
- order-slice.ts
- order-thunks.ts

## `frontend/src/redux-toolkit/orders` (4 items) — orders list slice

- orders-selector.ts
- orders-slice.ts
- orders-thunks.ts

## `frontend/src/redux-toolkit/perfume` (4 items) — single perfume slice

- perfume-selector.ts
- perfume-slice.ts
- perfume-thunks.ts

## `frontend/src/redux-toolkit/perfumes` (4 items) — perfumes list slice

- perfumes-selector.ts
- perfumes-slice.ts
- perfumes-thunks.ts

## `frontend/src/redux-toolkit/user` (4 items) — user slice

- user-selector.ts
- user-slice.ts
- user-thunks.ts

## `frontend/src/types` (2 items) — shared TypeScript types

- types.ts

## `frontend/src/utils` (15 items) — cross-cutting frontend utilities

- request-service.tsx

## `frontend/src/utils/graphql-query` (3 items) — GraphQL query definitions

- orders-query.ts
- perfume-query.ts
- users-query.ts

## `frontend/src/utils/oauth2` (1 items) — OAuth2 redirect handling

- OAuth2RedirectHandler.tsx

## `frontend/src/utils/test` (2 items) — test helpers and mocks

- testHelper.tsx
