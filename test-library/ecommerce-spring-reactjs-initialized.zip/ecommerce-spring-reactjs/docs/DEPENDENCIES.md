# Direct Dependencies

Direct dependencies only, as declared in `pom.xml` (`<dependencies>`) and `frontend/package.json` (`dependencies`). No transitive dependencies.

## Backend — module `ecommerce` (`pom.xml`)

| Package | Version |
|---|---|
| org.springframework.boot:spring-boot-starter-web | parent-managed (2.3.6.RELEASE) |
| org.springframework.boot:spring-boot-devtools | parent-managed (2.3.6.RELEASE) |
| org.postgresql:postgresql | parent-managed (2.3.6.RELEASE) |
| org.springframework.boot:spring-boot-starter-data-jpa | parent-managed (2.3.6.RELEASE) |
| org.springframework.boot:spring-boot-starter-security | parent-managed (2.3.6.RELEASE) |
| org.springframework.security:spring-security-test | parent-managed (2.3.6.RELEASE) |
| org.springframework.security:spring-security-taglibs | parent-managed (2.3.6.RELEASE) |
| org.springframework.security:spring-security-oauth2-client | parent-managed (2.3.6.RELEASE) |
| org.springframework.boot:spring-boot-starter-mail | parent-managed (2.3.6.RELEASE) |
| org.projectlombok:lombok | parent-managed (2.3.6.RELEASE) |
| org.flywaydb:flyway-core | 5.2.4 |
| javax.xml.bind:jaxb-api | 2.3.0 |
| com.sun.xml.bind:jaxb-core | 2.3.0 |
| com.sun.xml.bind:jaxb-impl | 2.3.0 |
| io.jsonwebtoken:jjwt | 0.9.1 |
| org.modelmapper:modelmapper | 2.3.9 |
| javax.validation:validation-api | 2.0.1.Final |
| org.hibernate:hibernate-validator | 6.1.6.Final |
| com.graphql-java:graphql-spring-boot-starter | 5.0.2 |
| com.graphql-java:graphql-java-tools | 5.2.4 |
| org.springframework.boot:spring-boot-starter-aop | 2.4.3 |
| io.springfox:springfox-swagger-common | 2.9.2 |
| io.springfox:springfox-swagger2 | 2.9.2 |
| io.springfox:springfox-swagger-ui | 2.9.2 |
| io.springfox:springfox-bean-validators | 2.9.2 |
| org.springframework.boot:spring-boot-starter-websocket | parent-managed (2.3.6.RELEASE) |
| com.amazonaws:aws-java-sdk | 1.11.133 |
| org.thymeleaf:thymeleaf | 3.0.11.RELEASE |
| org.thymeleaf:thymeleaf-spring5 | 3.0.11.RELEASE |
| org.springframework.boot:spring-boot-starter-test | parent-managed (2.3.6.RELEASE) |
| org.springframework:spring-test | 5.2.1.RELEASE |

## Frontend — module `frontend` (`frontend/package.json`)

| Package | Version |
|---|---|
| @ant-design/icons | ^4.7.0 |
| @apollo/client | ^3.3.13 |
| @reduxjs/toolkit | ^1.8.1 |
| @stomp/stompjs | ^6.1.0 |
| @testing-library/react | ^11.1.0 |
| @testing-library/user-event | ^12.1.10 |
| @types/antd | ^1.0.0 |
| @types/node | ^14.14.27 |
| @types/react | ^17.0.2 |
| @types/react-dom | ^17.0.1 |
| @types/sockjs-client | ^1.5.0 |
| antd | ^4.20.6 |
| axios | ^0.21.0 |
| axios-mock-adapter | ^1.19.0 |
| graphql | ^15.4.0 |
| react | ^17.0.1 |
| react-bootstrap | ^1.4.0 |
| react-dom | ^17.0.1 |
| react-google-recaptcha | ^2.1.0 |
| react-redux | ^7.2.2 |
| react-router-dom | ^5.2.0 |
| react-scripts | 4.0.3 |
| react-scroll-up | ^1.3.7 |
| redux-promise-middleware | ^6.1.2 |
| sockjs-client | ^1.5.1 |
| typescript | ^4.0.5 |
| web-vitals | ^0.2.4 |
