# Tech Stack

## Backend (repo root)

- Language: Java 1.8
- Framework: Spring Boot 2.3.6.RELEASE (`spring-boot-starter-parent`)
- Build tool: Maven, via Maven Wrapper (`mvnw`, `mvnw.cmd`, `.mvn/wrapper`)
- Database: PostgreSQL (runtime driver `org.postgresql:postgresql`)
- ORM: Spring Data JPA / Hibernate
- DB migrations: Flyway 5.2.4 (`src/main/resources/db/migration`)
- Security: Spring Security, Spring Security OAuth2 Client, JWT (`io.jsonwebtoken:jjwt` 0.9.1)
- API styles: REST (Spring MVC) and GraphQL (`graphql-spring-boot-starter` 5.0.2, `graphql-java-tools` 5.2.4, schema in `src/main/resources/graphql`)
- API docs: Springfox/Swagger 2.9.2 (`src/main/resources/static/swagger-api/swagger.yaml`)
- Realtime: WebSocket (`spring-boot-starter-websocket`)
- Templating: Thymeleaf 3.0.11.RELEASE (email templates)
- Object mapping: ModelMapper 2.3.9
- Cloud SDK: AWS SDK for Java 1.11.133
- Boilerplate reduction: Lombok
- Test tooling: `spring-boot-starter-test`, Spring Security Test, Maven Surefire 3.0.0-M5, JaCoCo 0.8.4 (coverage)
- Packaging: `spring-boot-maven-plugin`

## Frontend (`frontend/`)

- Language: TypeScript ^4.0.5
- Framework: React 17.0.1, bootstrapped with Create React App (`react-scripts` 4.0.3)
- Package manager: npm (`package-lock.json`)
- State management: Redux Toolkit ^1.8.1, react-redux ^7.2.2, redux-promise-middleware ^6.1.2
- API clients: Apollo Client ^3.3.13 + `graphql` ^15.4.0 (GraphQL), Axios ^0.21.0 (REST)
- Realtime: `@stomp/stompjs` ^6.1.0 over `sockjs-client` ^1.5.1
- UI library: Ant Design (`antd`) ^4.20.6, `@ant-design/icons` ^4.7.0, React Bootstrap ^1.4.0
- Routing: react-router-dom ^5.2.0
- Styling: CSS and Sass (`sass` ^1.55.0)
- Testing: Jest ^26.6.0, React Testing Library ^11.1.0, Enzyme ^3.11.0, `axios-mock-adapter` ^1.19.0
- Formatting: Prettier 2.6.2
