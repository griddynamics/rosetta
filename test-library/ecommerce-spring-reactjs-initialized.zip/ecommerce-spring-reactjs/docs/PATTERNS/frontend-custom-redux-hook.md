### Name: Custom Hook Encapsulating Local UI State + Dispatch

### Description

A hook in `hooks/*.ts` bundles one interaction's local `useState`, an optional `useSelector` read, and one or more handler functions that call `dispatch`, returning a single named interface (e.g. `UseSearch`, `UseCart`) instead of leaking raw dispatch/state to the component. Use when the same stateful interaction (search box, add-to-cart, pagination) is needed by more than one component and should not be reimplemented per page. Recurs across `useCart`, `useSearch`, `usePagination`, and `useTablePagination`.

### Template/Example

```ts
import { useState } from "react";
import { useDispatch } from "react-redux";
import { doSomething } from "../redux-toolkit/<domain>/<domain>-thunks";

interface UseInteraction {
    value: string;                         // extension point: exposed state
    onChange: (next: string) => void;      // extension point: exposed handlers
    submit: () => void;
}

export const useInteraction = (contextId?: number): UseInteraction => {
    const dispatch = useDispatch();
    const [value, setValue] = useState<string>("");

    const onChange = (next: string): void => {
        setValue(next);
    };

    const submit = (): void => {
        dispatch(doSomething({ contextId, value }));
    };

    return { value, onChange, submit };
};
```
