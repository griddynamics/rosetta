### Name: GraphQL Query Module + Thunk Dispatch

### Description

A GraphQL query is defined as a plain template-literal string builder in `utils/graphql-query/*.ts`, then sent as the `query` field of a POST body via the axios `RequestService` inside a `createAsyncThunk`, rather than through Apollo Client hooks (Apollo is initialized in `index.tsx` but not used for data fetching). Use when a domain thunk needs a GraphQL read that returns a nested object graph in one round trip; keeps GraphQL query text out of components and next to the thunk that consumes it. Recurs across `perfume`, `perfumes`, `orders`, `admin`, and `user` thunks.

### Template/Example

```ts
// utils/graphql-query/<domain>-query.ts
export const getEntityByQuery = (id: string) => `
    {
        entity(id: "${id}") {
            id
            // extension point: requested fields / nested relations
        }
    }
`;
```

```ts
// <domain>-thunks.ts
import { createAsyncThunk } from "@reduxjs/toolkit";
import RequestService from "../../utils/request-service";
import { GRAPHQL_ENDPOINT } from "../../constants/urlConstants";
import { getEntityByQuery } from "../../utils/graphql-query/<domain>-query";

export const fetchEntityByQuery = createAsyncThunk<any, string, { rejectValue: string }>(
    "domain/fetchEntityByQuery",
    async (id, thunkApi) => {
        try {
            const response = await RequestService.post(GRAPHQL_ENDPOINT, {
                query: getEntityByQuery(id)
            });
            return response.data.data.entity; // extension point: unwrap the query's root field name
        } catch (error) {
            return thunkApi.rejectWithValue(error.response.data);
        }
    }
);
```
