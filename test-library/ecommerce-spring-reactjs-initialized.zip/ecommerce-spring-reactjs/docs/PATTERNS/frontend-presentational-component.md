### Name: Reusable Presentational Component + Props Interface

### Description

A small, stateless (or locally-stateful) component under `components/<Name>/<Name>.tsx` declares a `PropsType`/named interface, destructures all inputs in the function signature, wraps a scoped `.css`/`.scss` file, and renders Ant Design primitives with optional callback props for parent-owned behavior. Use for any UI element reused across 2+ pages (card, labeled row, icon button, wrapper, spinner) to keep markup and styling out of page components. Recurs across `FormInput`, `IconButton`, `ContentTitle`, `ContentWrapper`, `PerfumeCard`, `AccountDataItem`, and `Spinner`.

### Template/Example

```tsx
import React, { FC, ReactElement, ReactNode } from "react";
import "./ComponentName.css";

type PropsType = {
    title: string;                       // extension point: required display data
    icon?: ReactNode;                    // extension point: optional slot content
    onAction?: () => void;               // extension point: parent-owned callback
};

const ComponentName: FC<PropsType> = ({ title, icon, onAction }): ReactElement => {
    return (
        <div className={"component-name"}>
            {icon}
            <span>{title}</span>
            {onAction && <button onClick={onAction}>Action</button>}
        </div>
    );
};

export default ComponentName;
```
