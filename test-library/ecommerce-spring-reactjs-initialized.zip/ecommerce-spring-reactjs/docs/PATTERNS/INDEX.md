# Patterns Index

## REST Controller Endpoint - controllers delegate to Mapper, return ResponseEntity, use HeaderResponse<T> for pagination metadata
File: backend-rest-controller-endpoint.md

## JPA Entity + Repository - Lombok entity with sequence @Id, paired JpaRepository with unpaged and Page<T> finder overloads
File: backend-jpa-entity-repository.md

## Service + DTO Mapper Layer - Service interface/Impl owns repository access and @Transactional writes; Mapper converts entities to DTOs via CommonMapper
File: backend-service-dto-mapper-layer.md

## GraphQL DataFetcher Bridge - per-service DataFetcher<T> factories wired centrally in GraphQLProvider, executed via REST POST with raw query string
File: backend-graphql-datafetcher-bridge.md

## Flyway Migration Naming - versioned immutable V<N>__Description.sql scripts under db/migration
File: backend-flyway-migration-naming.md

## Exception Handler / Error Response - typed RuntimeException subclasses translated to HTTP responses by one @ControllerAdvice
File: backend-exception-handler-error-response.md

## OAuth2 Provider Adapter - abstract OAuth2UserInfo base with per-provider subclasses selected via static factory on registration ID
File: backend-oauth2-provider-adapter.md

## Redux Toolkit Slice - co-located slice/thunks/selector triad per domain
File: frontend-redux-toolkit-slice.md

## Axios Request Service Facade - single class funneling get/post/put/delete through one header/base-URL builder
File: frontend-axios-request-service.md

## GraphQL Query + Thunk Dispatch - gql query strings sent via the axios facade inside createAsyncThunk
File: frontend-graphql-query-thunk.md

## Ant Design Form Page - ContentWrapper + ContentTitle + Form onFinish + FormInput + IconButton driven by slice state
File: frontend-antd-form-page.md

## Ant Design Table Page with Server-Side Pagination - mount-time fetch thunk + useTablePagination hook + reset-on-unmount
File: frontend-antd-table-page.md

## Reusable Presentational Component + Props Interface - typed PropsType, destructured props, scoped CSS
File: frontend-presentational-component.md

## Custom Redux Hook - bundles useState/useSelector/dispatch handlers behind one named return interface
File: frontend-custom-redux-hook.md
