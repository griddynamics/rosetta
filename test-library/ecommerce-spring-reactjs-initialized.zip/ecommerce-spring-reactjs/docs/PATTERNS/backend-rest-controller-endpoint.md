### Name: REST Controller Endpoint

### Description

Exposes a resource over HTTP using Spring MVC. A `@RestController` is annotated with a base `@RequestMapping` built from shared `PathConstants`, injects a single `Mapper` component via constructor (Lombok `@RequiredArgsConstructor`), and each handler method delegates all business logic to that mapper, wrapping the result in `ResponseEntity`. Paginated list endpoints accept a `Pageable` (`@PageableDefault`) and return the page as HTTP headers via a generic `HeaderResponse<T>` wrapper. Use when adding a new HTTP resource that needs CRUD/search endpoints without embedding logic in the controller.

### Template/Example
```java
@RestController
@RequiredArgsConstructor
@RequestMapping(API_V1_RESOURCE) // extension point: add path constant to PathConstants
public class ResourceController {

    private final ResourceMapper resourceMapper; // extension point: inject mapper, not service, from controller

    @GetMapping(RESOURCE_ID)
    public ResponseEntity<ResourceResponse> getResourceById(@PathVariable Long resourceId) {
        return ResponseEntity.ok(resourceMapper.getResourceById(resourceId));
    }

    @GetMapping
    public ResponseEntity<List<ResourceResponse>> getAllResources(@PageableDefault(size = 15) Pageable pageable) {
        HeaderResponse<ResourceResponse> response = resourceMapper.getAllResources(pageable);
        // extension point: HeaderResponse carries total-pages/total-elements as HTTP headers instead of a response envelope
        return ResponseEntity.ok().headers(response.getHeaders()).body(response.getItems());
    }

    @PostMapping
    public ResponseEntity<ResourceResponse> createResource(@Valid @RequestBody ResourceRequest request,
                                                            BindingResult bindingResult) {
        // extension point: validation errors surface via BindingResult, mapper throws InputFieldException
        return ResponseEntity.ok(resourceMapper.createResource(request, bindingResult));
    }
}
```
