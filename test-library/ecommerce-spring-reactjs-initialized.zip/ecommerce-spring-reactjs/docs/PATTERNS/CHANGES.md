## [2026-07-15] Initial pattern extraction (install mode)

- Created 7 backend patterns and 7 frontend patterns, plus INDEX.md.
- Excluded (no 2+ recurrence, one-off): backend `security` JWT chain (JwtFilter/JwtProvider/JwtConfigurer/WebSecurityConfiguration), `aspect` AOP logging, `EmailConfiguration`, `WebSocketConfiguration`, `SwaggerConfiguration`, plain enums (AuthProvider/Role/SearchPerfume).
- Excluded (no 2+ recurrence): frontend Apollo Client `useQuery`/`useMutation` hook pattern (dependency declared and initialized but unused — all GraphQL calls go through the axios facade as raw query strings, see `frontend-graphql-query-thunk.md`), and a "Protected Route" component (only one authenticated route, guarded inline in `App.tsx`).
