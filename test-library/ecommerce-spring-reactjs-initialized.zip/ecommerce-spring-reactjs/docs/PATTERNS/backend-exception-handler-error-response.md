### Name: Exception Handler / Error Response

### Description

Models each domain error as a small `RuntimeException` subclass carrying only the fields needed to render the error message (`@Getter`, no stack-trace-worthy payload), and centralizes translation to HTTP responses in one `@ControllerAdvice` with one `@ExceptionHandler` method per exception type returning a `ResponseEntity` with the appropriate status and body. Use when a new failure case needs a distinct, typed error response instead of a generic 500.

### Template/Example
```java
@Getter
public class ResourceConflictException extends RuntimeException {
    private final String conflictError; // extension point: fields carried into the error response body

    public ResourceConflictException(String conflictError) {
        this.conflictError = conflictError;
    }
}

@ControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(ApiRequestException.class)
    public ResponseEntity<String> handleApiRequestException(ApiRequestException exception) {
        return ResponseEntity.status(exception.getStatus()).body(exception.getMessage());
    }

    @ExceptionHandler(ResourceConflictException.class)
    public ResponseEntity<ResourceConflictException> handleResourceConflict(ResourceConflictException exception) {
        // extension point: one handler method per custom exception type, mapped to its HTTP status
        return ResponseEntity.badRequest().body(new ResourceConflictException(exception.getConflictError()));
    }
}
```
