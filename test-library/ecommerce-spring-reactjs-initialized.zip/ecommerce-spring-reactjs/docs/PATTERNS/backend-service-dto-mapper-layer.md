### Name: Service Layer + DTO Mapper

### Description

Separates persistence access from HTTP-facing shapes with two collaborating layers: a `Service` interface/`Impl` pair that owns repository access, transactions (`@Transactional`), and domain-exception translation (`orElseThrow(() -> new ApiRequestException(...))`); and a `Mapper` component that the controller calls, which converts entities to response DTOs (via a shared `CommonMapper`/ModelMapper) and builds `HeaderResponse` for paged results. Use when a resource needs its persistence model kept separate from its wire-format DTOs.

### Template/Example
```java
public interface ResourceService {
    Resource getResourceById(Long id);
    Page<ResourceProjection> getAllResources(Pageable pageable);
    Resource saveResource(Resource resource);
}

@Service
@RequiredArgsConstructor
public class ResourceServiceImpl implements ResourceService {

    private final ResourceRepository resourceRepository;

    @Override
    public Resource getResourceById(Long id) {
        return resourceRepository.findById(id)
                .orElseThrow(() -> new ApiRequestException(RESOURCE_NOT_FOUND, HttpStatus.NOT_FOUND));
        // extension point: swap ApiRequestException message/status per resource
    }

    @Override
    public Page<ResourceProjection> getAllResources(Pageable pageable) {
        return resourceRepository.findAllByOrderByIdAsc(pageable);
    }

    @Override
    @Transactional // extension point: mark write operations transactional
    public Resource saveResource(Resource resource) {
        return resourceRepository.save(resource);
    }
}

@Component
@RequiredArgsConstructor
public class ResourceMapper {

    private final CommonMapper commonMapper;
    private final ResourceService resourceService;

    public ResourceResponse getResourceById(Long id) {
        return commonMapper.convertToResponse(resourceService.getResourceById(id), ResourceResponse.class);
    }

    public HeaderResponse<ResourceResponse> getAllResources(Pageable pageable) {
        Page<ResourceProjection> page = resourceService.getAllResources(pageable);
        return commonMapper.getHeaderResponse(page.getContent(), page.getTotalPages(), page.getTotalElements(), ResourceResponse.class);
    }
}
```
