### Name: JPA Entity + Repository

### Description

Defines a persistent domain entity with Lombok-generated accessors, an identity-only `equals`/`hashCode`, and a database sequence-backed primary key, paired with a `JpaRepository` that adds derived-query finder methods plus paginated (`Page<T>`) overloads of the same finder for list endpoints. Use when introducing a new persisted domain concept that needs both unpaged and paged lookups.

### Template/Example
```java
@Getter
@Setter
@ToString
@Entity
@Table(name = "resource_table") // extension point: table name
public class Resource {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "resource_seq")
    @SequenceGenerator(name = "resource_seq", sequenceName = "resource_seq", allocationSize = 1)
    @Column(name = "id")
    private Long id;

    @Column(name = "name") // extension point: additional @Column fields
    private String name;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Resource resource = (Resource) o;
        return Objects.equals(id, resource.id); // identity-only equality
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

@Repository
public interface ResourceRepository extends JpaRepository<Resource, Long> {

    List<Resource> findAllByOrderByIdAsc();

    Page<Resource> findAllByOrderByIdAsc(Pageable pageable); // extension point: paged twin of every list finder

    List<Resource> findByName(String name);

    Page<Resource> findByName(String name, Pageable pageable);
}
```
