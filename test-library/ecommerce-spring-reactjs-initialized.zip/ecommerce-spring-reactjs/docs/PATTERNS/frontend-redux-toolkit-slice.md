### Name: Redux Toolkit Slice (Selector / Slice / Thunks Triad)

### Description

Encapsulates one domain's client-side state as three co-located files — `*-slice.ts` (state shape + sync reducers + `extraReducers` for async lifecycle), `*-thunks.ts` (`createAsyncThunk` calls that hit REST or GraphQL endpoints), and `*-selector.ts` (typed read accessors over `RootState`). Use when a domain area (list, detail, or account resource) needs loading/error/data state shared across components. Recurs identically across `admin`, `auth`, `cart`, `order`, `orders`, `perfume`, `perfumes`, and `user` slices.

### Template/Example

```ts
// <domain>-slice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { LoadingStatus /*, YourEntityResponse */ } from "../../types/types";
import { fetchEntity } from "./<domain>-thunks";

export interface DomainState {
    entity: /* YourEntityResponse */ any;
    errorMessage: string;
    loadingState: LoadingStatus;
}

export const initialState: DomainState = {
    entity: {},          // extension point: shape per domain
    errorMessage: "",
    loadingState: LoadingStatus.LOADING
};

export const domainSlice = createSlice({
    name: "domain",      // extension point: unique slice name
    initialState,
    reducers: {
        // extension point: synchronous, locally-driven mutations
        resetDomainState: () => initialState
    },
    extraReducers: (builder) => {
        builder.addCase(fetchEntity.pending, (state) => {
            state.loadingState = LoadingStatus.LOADING;
        });
        builder.addCase(fetchEntity.fulfilled, (state, action) => {
            state.entity = action.payload;
            state.loadingState = LoadingStatus.LOADED;
        });
        builder.addCase(fetchEntity.rejected, (state, action) => {
            state.errorMessage = action.payload as string;
            state.loadingState = LoadingStatus.ERROR;
        });
        // extension point: addCase per additional thunk
    }
});

export const { resetDomainState } = domainSlice.actions;
export default domainSlice.reducer;
```

```ts
// <domain>-thunks.ts
import { createAsyncThunk } from "@reduxjs/toolkit";
import RequestService from "../../utils/request-service";
import { ENTITY_URL } from "../../constants/urlConstants";

export const fetchEntity = createAsyncThunk<any, string, { rejectValue: string }>(
    "domain/fetchEntity",           // extension point: "<domain>/<action>" type string
    async (id, thunkApi) => {
        try {
            const response = await RequestService.get(`${ENTITY_URL}/${id}`);
            return response.data;
        } catch (error) {
            return thunkApi.rejectWithValue(error.response.data);
        }
    }
);
```

```ts
// <domain>-selector.ts
import { RootState } from "../../store";
import { DomainState } from "./<domain>-slice";

export const selectDomainState = (state: RootState): DomainState => state.domain; // extension point: key
export const selectEntity = (state: RootState) => state.domain.entity;
export const selectLoadingStatus = (state: RootState) => selectDomainState(state).loadingState;
export const selectIsLoading = (state: RootState) => selectLoadingStatus(state) === LoadingStatus.LOADING;
```
