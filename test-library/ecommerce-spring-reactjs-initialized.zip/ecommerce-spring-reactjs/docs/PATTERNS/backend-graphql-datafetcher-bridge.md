### Name: GraphQL DataFetcher over REST Bridge

### Description

Implements GraphQL queries without per-type resolver classes: each `Service` exposes `DataFetcher<T>` factory methods (one per schema `Query` field) implemented as repository-backed lambdas, all wired centrally in one `GraphQLProvider` (`RuntimeWiring.newRuntimeWiring().type("Query", ...)`) built from `schemas.graphql`. Controllers then expose the compiled `GraphQL` executable over plain REST `POST` endpoints, executing a client-supplied query string. Use when a resource needs GraphQL-style flexible querying alongside its existing REST endpoints, without introducing a full GraphQL resolver framework.

### Template/Example
```java
// Service: one DataFetcher-returning method per schema Query field
public interface ResourceService {
    DataFetcher<Resource> getResourceByQuery();
    DataFetcher<List<Resource>> getAllResourcesByQuery();
}

@Service
public class ResourceServiceImpl implements ResourceService {
    private final ResourceRepository resourceRepository;

    @Override
    public DataFetcher<Resource> getResourceByQuery() {
        return env -> {
            Long id = Long.parseLong(env.getArgument("id")); // extension point: argument extraction per field
            return resourceRepository.findById(id).get();
        };
    }

    @Override
    public DataFetcher<List<Resource>> getAllResourcesByQuery() {
        return env -> resourceRepository.findAllByOrderByIdAsc();
    }
}

// Central wiring: register each service's DataFetchers against schema field names
@Component
@RequiredArgsConstructor
public class GraphQLProvider {
    private final ResourceService resourceService;

    @Getter
    private GraphQL graphQL;

    @PostConstruct
    public void loadSchema() throws IOException {
        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(resource.getFile());
        RuntimeWiring wiring = RuntimeWiring.newRuntimeWiring()
                .type("Query", tw -> tw
                        .dataFetcher("resource", resourceService.getResourceByQuery())
                        .dataFetcher("resources", resourceService.getAllResourcesByQuery()))
                // extension point: add one .dataFetcher(...) line per new schema field
                .build();
        graphQL = GraphQL.newGraphQL(new SchemaGenerator().makeExecutableSchema(typeRegistry, wiring)).build();
    }
}

// REST bridge endpoint per query, executing a client-supplied query string
@PostMapping(GRAPHQL_RESOURCE)
public ResponseEntity<ExecutionResult> getResourceByQuery(@RequestBody GraphQLRequest request) {
    return ResponseEntity.ok(graphQLProvider.getGraphQL().execute(request.getQuery()));
}
```
