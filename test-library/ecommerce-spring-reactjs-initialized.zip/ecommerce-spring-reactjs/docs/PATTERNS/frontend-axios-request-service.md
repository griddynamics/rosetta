### Name: Axios Request Service Facade

### Description

A single class exposing `get/post/put/delete` methods that all funnel through one private `createRequest` builder, centralizing base URL prefixing, auth-header toggling (`isAuthRequired`), and content-type header. Use when every outbound HTTP call (REST or GraphQL-over-HTTP) must share consistent headers and error propagation without repeating axios config at each call site. Every one of the 7+ thunk modules calls this same facade instead of axios directly.

### Template/Example

```tsx
// utils/request-service.tsx
import axios, { Method } from "axios";
import { API_BASE_URL } from "../constants/urlConstants";

class RequestService {
    get = (url: string, isAuthRequired: boolean = false, contentType: string = "application/json") =>
        createRequest("GET", url, null, isAuthRequired, contentType);

    post = (url: string, body: any, isAuthRequired: boolean = false, contentType: string = "application/json") =>
        createRequest("POST", url, body, isAuthRequired, contentType);

    put = (url: string, body: any, isAuthRequired: boolean = false, contentType: string = "application/json") =>
        createRequest("PUT", url, body, isAuthRequired, contentType);

    delete = (url: string, isAuthRequired: boolean = false, contentType: string = "application/json") =>
        createRequest("DELETE", url, null, isAuthRequired, contentType);

    // extension point: add methods (e.g. patch) following the same signature
};

const createRequest = (method: Method, url: string, body: any, isAuthRequired: boolean, contentType: string) => {
    return axios({
        method,
        url: API_BASE_URL + url,        // extension point: base URL source
        data: body,
        headers: setHeader(isAuthRequired, contentType)
    });
};

const setHeader = (isAuthRequired: boolean, contentType: string) => {
    if (isAuthRequired) {
        axios.defaults.headers.common["Authorization"] = localStorage.getItem("token"); // extension point: token source
    } else {
        delete axios.defaults.headers.common["Authorization"];
    }
    axios.defaults.headers.common["Content-Type"] = contentType;
};

export default new RequestService();
```

```ts
// caller (e.g. a thunk) — uniform usage regardless of verb
import RequestService from "../../utils/request-service";

const response = await RequestService.get(SOME_URL, /* isAuthRequired */ true);
const created = await RequestService.post(SOME_URL, payload, true);
```
