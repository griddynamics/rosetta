### Name: Ant Design Form Page

### Description

A route-level page wraps an Ant Design `<Form onFinish>` inside `ContentWrapper` + `ContentTitle`, composes fields from the shared `FormInput` component, submits via `IconButton`, and reads submit errors/loading/success from a Redux slice tied to `useEffect` mount/unmount (dispatch fetch or reset-state on unmount). Use for any single-purpose data-entry screen (sign in, sign up, forgot/reset password, add/edit an entity, change password). Recurs across `Login`, `Registration`, `ForgotPassword`, `ResetPassword`, `ChangePassword`, `AddPerfume`, and `EditPerfume`.

### Template/Example

```tsx
import React, { FC, ReactElement, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Alert, Col, Divider, Form, Row } from "antd";

import ContentWrapper from "../../components/ContentWrapper/ContentWrapper";
import ContentTitle from "../../components/ContentTitle/ContentTitle";
import FormInput from "../../components/FormInput/FormInput";
import IconButton from "../../components/IconButton/IconButton";
import { selectErrorMessage } from "../../redux-toolkit/<domain>/<domain>-selector";
import { resetDomainState } from "../../redux-toolkit/<domain>/<domain>-slice";
import { submitEntity } from "../../redux-toolkit/<domain>/<domain>-thunks";

const FormPage: FC = (): ReactElement => {
    const dispatch = useDispatch();
    const errorMessage = useSelector(selectErrorMessage);

    useEffect(() => {
        window.scrollTo(0, 0);
        return () => {
            dispatch(resetDomainState());          // extension point: cleanup on leave
        };
    }, []);

    const onSubmit = (formData: any): void => {
        dispatch(submitEntity(formData));           // extension point: thunk + payload shape
    };

    return (
        <ContentWrapper>
            <ContentTitle icon={/* <Icon /> */ null} title={"PAGE TITLE"} />
            <Row gutter={32}>
                <Col span={12}>
                    <Form onFinish={onSubmit}>
                        <Divider />
                        {errorMessage && <Alert type="error" message={errorMessage} />}
                        <FormInput
                            title={"Field label:"}
                            titleSpan={8}
                            wrapperSpan={16}
                            name={"fieldName"}          // extension point: repeat per field
                            placeholder={"Field placeholder"}
                        />
                        <IconButton title={"Submit"} icon={/* <Icon /> */ null} />
                    </Form>
                </Col>
            </Row>
        </ContentWrapper>
    );
};

export default FormPage;
```
