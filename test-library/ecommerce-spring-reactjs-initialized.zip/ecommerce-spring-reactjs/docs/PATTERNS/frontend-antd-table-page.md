### Name: Ant Design Table Page with Server-Side Pagination

### Description

A list page or reusable table component dispatches a paginated fetch thunk on mount, reads `data`/`loading`/`totalElements` from a slice via selectors, wires Ant Design's `<Table onChange>` to the shared `useTablePagination` hook (which re-dispatches the fetch thunk on page change only), and resets the slice's state on unmount. Use for any admin or account list view backed by server-side paging (users, orders, perfumes). Recurs across `UsersList`, `OrdersTable`, `PersonalOrdersList`, `ManageUserOrder`, and `PerfumeList`.

### Template/Example

```tsx
import React, { FC, ReactElement, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Table } from "antd";

import { selectEntities, selectIsLoading, selectTotalElements } from "../../redux-toolkit/<domain>/<domain>-selector";
import { fetchEntities } from "../../redux-toolkit/<domain>/<domain>-thunks";
import { resetDomainState } from "../../redux-toolkit/<domain>/<domain>-slice";
import { useTablePagination } from "../../hooks/useTablePagination";

const ListPage: FC = (): ReactElement => {
    const dispatch = useDispatch();
    const entities = useSelector(selectEntities);
    const isLoading = useSelector(selectIsLoading);
    const totalElements = useSelector(selectTotalElements);
    const handleTableChange = useTablePagination<any, number>(fetchEntities); // extension point: item/page-param types

    useEffect(() => {
        dispatch(fetchEntities(0));
        return () => {
            dispatch(resetDomainState());
        };
    }, []);

    return (
        <Table
            rowKey={"id"}
            onChange={handleTableChange}
            loading={isLoading}
            pagination={{ total: totalElements, position: ["bottomRight", "topRight"] }}
            dataSource={entities}
            columns={[
                // extension point: one column descriptor per displayed field
                { title: "Id", dataIndex: "id", key: "id" }
            ]}
        />
    );
};

export default ListPage;
```

```ts
// hooks/useTablePagination.ts — shared page-change adapter reused by every table page above
import { useDispatch } from "react-redux";
import { AsyncThunkAction } from "@reduxjs/toolkit";
import { TableCurrentDataSource, TablePaginationConfig } from "antd/lib/table/interface";
import { HeaderResponse } from "../types/types";

export const useTablePagination = <T, S>(
    getPaginationItems: (page: S) => AsyncThunkAction<HeaderResponse<T>, S, {}>
) => {
    const dispatch = useDispatch();
    return (pagination: TablePaginationConfig, _filters: any, _sorter: any, extra: TableCurrentDataSource<T>): void => {
        if (extra.action === "paginate") {
            dispatch(getPaginationItems((pagination.current! - 1) as unknown as S));
        }
    };
};
```
