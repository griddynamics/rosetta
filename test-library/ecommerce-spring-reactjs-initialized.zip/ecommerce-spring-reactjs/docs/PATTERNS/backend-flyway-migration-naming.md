### Name: Flyway Migration Naming

### Description

Orders database schema changes as sequential, immutable versioned SQL scripts under `src/main/resources/db/migration`, named `V<N>__<Description>.sql` with an incrementing integer version and an underscore-separated description. Use when any schema or seed-data change is needed; never edit a previously applied migration.

### Template/Example
```sql
-- File: V<N>__<Short_Description>.sql
-- extension point: <N> is the next unused integer version; description uses underscores, no spaces

alter table resource_table
    add column status varchar(32);

-- extension point: seed/reference data as plain insert statements, one row per statement
insert into resource_table(id, name, status)
    values (1, 'example', 'ACTIVE');
```
