### Name: OAuth2 Provider UserInfo Adapter

### Description

Normalizes profile attributes from multiple OAuth2 identity providers (Google, Facebook, GitHub) behind one abstract class with provider-specific subclasses, selected at runtime by a static factory keyed on the OAuth2 registration ID / `AuthProvider` enum. Use when adding support for a new "Sign in with X" provider whose raw attribute map shape differs from existing providers.

### Template/Example
```java
public abstract class OAuth2UserInfo {
    protected Map<String, Object> attributes;

    public OAuth2UserInfo(Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    public abstract String getId();
    public abstract String getFirstName();
    public abstract String getLastName();
    public abstract String getEmail();
}

public class NewProviderOAuth2UserInfo extends OAuth2UserInfo {
    public NewProviderOAuth2UserInfo(Map<String, Object> attributes) {
        super(attributes);
    }

    @Override
    public String getId() { return (String) attributes.get("id"); } // extension point: provider-specific attribute keys

    @Override
    public String getFirstName() { return (String) attributes.get("first_name"); }

    @Override
    public String getLastName() { return (String) attributes.get("last_name"); }

    @Override
    public String getEmail() { return (String) attributes.get("email"); }
}

public class OAuth2UserFactory {
    @SneakyThrows
    public static OAuth2UserInfo getOAuth2UserInfo(String registrationId, Map<String, Object> attributes) {
        if (registrationId.equalsIgnoreCase(AuthProvider.GOOGLE.toString())) {
            return new GoogleOAuth2UserInfo(attributes);
        } else if (registrationId.equalsIgnoreCase(AuthProvider.NEW_PROVIDER.toString())) {
            return new NewProviderOAuth2UserInfo(attributes);
            // extension point: add one branch + enum value per supported provider
        } else {
            throw new AuthenticationException();
        }
    }
}
```
