# TODO

Improvements and large follow-ups discovered but out of scope for the current task. Each entry: header with priority, when, what, where; body with details.

## [MEDIUM] Before initializing SCM — externalize hardcoded config values — src/main/resources/application.properties

Plaintext values are checked into `application.properties`: `[REDACTED:SMTP_PASSWORD]`, `[REDACTED:OAUTH2_CLIENT_SECRET]` (Google, Facebook, GitHub), `[REDACTED:AWS_ACCESS_KEY]` + `[REDACTED:AWS_SECRET_KEY]`. User confirmed (2026-07-15) these are dummy/decommissioned sample values, not active credentials — no immediate rotation needed. Still externalize via environment variables / a secrets manager before real credentials are ever used, and before initializing SCM (see next item), so real values never enter commit history.

## [HIGH] Now — decide SCM/issue-tracker/wiki tooling — gain.json

No .git repository exists yet and issue tracker/wiki are unset. Update `gain.json` sdlc.* fields once decided.

## [DONE] Apollo Client — drop unused dependency — frontend/package.json

Decided (2026-07-15): drop `@apollo/client` — GraphQL calls stay on the working Axios-facade + raw-query-string pattern (`frontend-graphql-query-thunk.md`). Remove the dependency and its `index.tsx` initialization when next touching frontend deps.

