# Assumptions

This doc tracks unresolved unknowns discovered during workspace analysis. Each entry: assumption, confidence, target file to update once resolved. Revalidate after any related doc changes.

## Open Assumptions

### SDLC tooling not yet chosen
- Assumption: issue tracker, wiki, SCM host, build management, monitoring, logging, and e2e-test tooling are undecided (placeholders in gain.json); hosting is on-prem/self-hosted per user decision.
- Confidence: high (user-confirmed as "not decided yet" during init).
- Target: gain.json

### No git repository initialized
- Assumption: source control has not been set up yet for this workspace (no .git directory found at init time).
- Confidence: high (verified: no .git anywhere in workspace).
- Target: gain.json (sdlc.scm)
