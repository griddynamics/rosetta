# Architecture

This document describes the technical architecture of this workspace: its style, module structure, build tooling, testing, styling, and the named building-block patterns. It is source-agnostic and state-only. For business context see `docs/CONTEXT.md`. For the full file/directory layout see `docs/CODEMAP.md`; for versions see `docs/TECHSTACK.md` and `docs/DEPENDENCIES.md`.

## Style

Two deployable units in one repository:

- Backend: a Spring Boot monolith at the repo root, exposing both REST (Spring MVC) and GraphQL over HTTP, backed by PostgreSQL via Spring Data JPA/Hibernate.
- Frontend: a separate React single-page application under `frontend/`, bootstrapped with Create React App, consuming the backend API.

The two communicate over HTTP (REST and GraphQL) plus a STOMP-over-WebSocket channel for realtime messages. There is no shared build; each unit builds, tests, and deploys independently.

## Backend structure

Java package root: `src/main/java/com/gmail/merikbest2015/ecommerce`. Layered by responsibility:

- `controller` — REST endpoints, delegate to services and mappers, return `ResponseEntity`.
- `service` — business-logic interfaces with `Impl` classes owning repository access and `@Transactional` writes.
- `repository` — Spring Data JPA repositories.
- `domain` — JPA entities (`Order`, `OrderItem`, `Perfume`, `Review`, `User`).
- `mapper` — entity/DTO conversion via a shared `CommonMapper`.
- `dto` — request/response payloads.
- `graphql` — GraphQL `DataFetcher` wiring alongside the schema in `resources/graphql`.
- `security` — JWT filter/provider/configurer and `UserDetailsService`.
- `configuration` — Spring bean and app configuration (`WebSecurityConfiguration`, `WebSocketConfiguration`, `EmailConfiguration`, `MvcConfiguration`, `SwaggerConfiguration`, `ApplicationConfiguration`).
- `exception` — typed exceptions and one `@ControllerAdvice` handler.
- `enums`, `constants`, `aspect` — supporting cross-cutting code (`AuthProvider`, `Role`, path/error constants, AOP logging).

Persistence schema is managed by Flyway migrations under `resources/db/migration`. Email uses Thymeleaf templates under `resources/mail-templates`. API is documented via Springfox/Swagger. Product images are stored in Amazon S3 via the AWS SDK (`configuration.ApplicationConfiguration` builds the `AmazonS3` client bean, `service.Impl.PerfumeServiceImpl` uploads/reads images). Entity/DTO mapping uses ModelMapper alongside the `mapper`/`CommonMapper` layer.

## Frontend structure

App source under `frontend/src`. Layered by concern:

- `pages` — route-level screens (Home, Menu, Product, Cart, OrderFinalize, Order, Account, auth pages).
- `components` — reusable presentational components, each co-located with a `__tests__` folder.
- `redux-toolkit` — Redux Toolkit state, one folder per domain (admin, auth, cart, order, orders, perfume, perfumes, user), each a slice/thunks/selector triad.
- `utils` — cross-cutting helpers: the Axios request service facade, GraphQL query strings, OAuth2 redirect handling, test helpers.
- `hooks` — custom React hooks (`useCart`, `usePagination`, `useSearch`, `useTablePagination`).
- `constants`, `types`, `img` — routes/URLs, shared TypeScript types, static assets.

Routing is client-side via `react-router-dom`. The store is composed in `store.ts`; the app mounts from `index.tsx`/`App.tsx`.

## API integration note

Both REST and GraphQL are served by the backend. The frontend consumes REST and GraphQL through a single Axios facade — GraphQL queries are sent as raw query strings via HTTP POST inside Redux thunks. GraphQL is internal-only (this repo's frontend is the sole consumer, no external contract guarantees). Apollo Client is a declared but unused dependency, slated for removal (see `docs/TODO.md`).

## Build tooling

- Backend: Maven via the Maven Wrapper (`mvnw`). Packaged with `spring-boot-maven-plugin`. Coverage via JaCoCo.
- Frontend: npm with `react-scripts` (Create React App). Formatting via Prettier.

## Testing

- Backend: `spring-boot-starter-test` (JUnit, Mockito) plus Spring Security Test, run by Maven Surefire. Tests mirror the main package under `src/test/java`: controller integration tests, service `Impl` unit tests, and mapper unit tests. Fixtures and `application-test.properties` under `src/test/resources`.
- Frontend: Jest with React Testing Library (Enzyme also present) and `axios-mock-adapter`, configured via `jest.config.js`; specs co-located per component in `__tests__` folders.

## Styling

Ant Design is the primary UI component library, supplemented by React Bootstrap. Component-level styling uses plain CSS and Sass (`.css`/`.scss`) co-located with each component.

## Key building blocks

Named patterns govern how code is written in each area. See `docs/PATTERNS/INDEX.md` for details; do not restate them here. Backend: `REST Controller Endpoint`, `JPA Entity + Repository`, `Service + DTO Mapper Layer`, `GraphQL DataFetcher Bridge`, `Flyway Migration Naming`, `Exception Handler / Error Response`, `OAuth2 Provider Adapter`. Frontend: `Redux Toolkit Slice`, `Axios Request Service Facade`, `GraphQL Query + Thunk Dispatch`, `Ant Design Form Page`, `Ant Design Table Page with Server-Side Pagination`, `Reusable Presentational Component + Props Interface`, `Custom Redux Hook`.
