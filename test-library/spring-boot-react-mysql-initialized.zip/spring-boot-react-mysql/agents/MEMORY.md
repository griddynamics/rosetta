# AGENT MEMORY

Generalized reusable lessons from agent sessions.
Root causes converted into preventive rules, not incident-specific notes.
Entries are h3 headers with [ACTIVE|RETIRED] status.
Content: brief, grep-friendly, MECE across sections.
Style: one-liner per entry, optional sub-bullets for context.
Keep template entries so future agents know how to fill them in.

Operational notes only — not a duplicate of `docs/CONTEXT.md` or `docs/ARCHITECTURE.md`.
Seeded at Rosetta init (2026-07-15); no prior incidents yet.

## Preventive Rules

### Do not assume a canonical styling or component paradigm [ACTIVE]
Frontend mixes Bootstrap 4 + Tailwind and class + hook components; no convention is decided yet
(see `docs/ASSUMPTIONS.md` D1/D2). Confirm with user before standardizing.

### <Generalized Preventive Rule> [ACTIVE|RETIRED]
[Root cause, Reasons, Problems]

## What Worked

### <Generalized What Worked> [ACTIVE|RETIRED]
[Root cause, Reasons, Problems]

## What Failed

### <Generalized What Failed> [ACTIVE|RETIRED]
[Hypothesis, Root cause, Reasons, Problems]

## Discoveries

### Fresh Rosetta bootstrap; source is the only truth [ACTIVE]
Workspace initialized via `init-workspace-flow`. Prior README files were removed; treat code + `docs/`
as authoritative. Code navigation: use CODEMAP + LSPs (jdtls-lsp, typescript-lsp).

### <Generalized Discovery> [ACTIVE|RETIRED]
[Usage, Reasons, Problems]
