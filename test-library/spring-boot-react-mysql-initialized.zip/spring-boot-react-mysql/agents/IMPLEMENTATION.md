# Implementation Summary

Brief, durable summary of the current implementation state and the single change log of record.
Concise, not a chronological work journal. For detail use git history and PRs.
Business context: `docs/CONTEXT.md`. Architecture: `docs/ARCHITECTURE.md`.

## Baseline (2026-07-15, Rosetta init)

State captured at workspace initialization. Composite app: `react-client` + `spring-boot-server`.

### Backend (`spring-boot-server`)

- Spring Boot 3.1.0 / Java 17 REST API under `/api`, package `com.bezkoder.spring.datajpa`.
- Entities: `Tutorial`, `Comment` (self-referencing threaded replies), `Rating` (unique per tutorial+user).
- Controllers: `TutorialController` (CRUD, title search, delete-all, top-rated, most-discussed),
  `CommentController` (list/create/delete, count), `RatingController` (create-or-update, stats, user rating, delete).
- Repositories: `TutorialRepository`, `CommentRepository`, `RatingRepository` — derived queries + JPQL aggregates.
- DTOs split read (`*DTO`) vs write (`Create*Request`); controller-level entity→DTO mapping.
- Config: `WebConfig` (global CORS); `application.properties` with H2 active, MySQL commented out.
- Tests: context-load smoke test only.

### Frontend (`react-client`)

- React 18.2 SPA, Router v6 routes: featured, list, add, view, edit.
- `tutorial.service.js` Axios singleton over `http-common.js` (base URL hardcoded to `localhost:8080/api`).
- Components: `tutorials-list`, `add-tutorial`, `tutorial` (edit), `tutorial-view`, `featured-tutorials`
  (class components + `withRouter` HOC); `comments`, `star-rating` (function components + hooks).
- Anonymous identity via `window.prompt` + `localStorage`; confirm-before-delete; auto-dismiss status messages.
- Styling: Bootstrap 4 + Tailwind mixed.

Known consistency gaps are tracked in `docs/ASSUMPTIONS.md` (resolved in Phase 8, see below), current
baseline vs target-state gaps tracked in `docs/ARCHITECTURE.md` → Target-State Improvements.

## Target State — Testing

- Goal: achieve meaningful test coverage (Phase 8 decision; no fixed percentage target).
- Baseline gap: backend has only a context-load smoke test (no controller/repository/entity tests);
  frontend has RTL/Jest available but no meaningful component tests. Neither implemented yet.

## Known Unused Code

- `CommentRepository.findByTutorialId` — defined but not called by any in-scope controller. Phase 8
  decision: leave in place, do not delete (see `docs/ASSUMPTIONS.md` D14).

## Change Log

Each change: an h3 header with date and short description, body with keywords and references.

### 2026-07-15: Rosetta workspace initialization

- Ran `init-workspace-flow` Phases 1–7. Produced `docs/` (CONTEXT, ARCHITECTURE, TECHSTACK, CODEMAP,
  DEPENDENCIES, PATTERNS, ASSUMPTIONS) and `agents/` (IMPLEMENTATION, MEMORY, state). No application code changed.

### 2026-07-15: Phase 8 (Questions) — decisions recorded

- Applied 19 user HITL decisions to docs only, no application code changed. Resolved all D1–D15 and U1 in
  `docs/ASSUMPTIONS.md`; added Target-State Improvements section to `docs/ARCHITECTURE.md`; recorded testing
  goal and dead-code note above; created `docs/TODO.md` with README-regeneration follow-up and improvement
  backlog cross-reference.
