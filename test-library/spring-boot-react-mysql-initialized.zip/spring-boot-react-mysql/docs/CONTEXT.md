# CONTEXT

Business purpose, actors, domain, and behavior of this workspace — the "what" and "why".
Stakeholder perspective only. No technical detail (see `ARCHITECTURE.md` for the "how").
Style: terse bullets, grep-friendly headers. Always loaded into agent context.

## Purpose

- Web application for sharing and discovering short technical tutorials.
- Visitors browse tutorials, read and post threaded comments, and give 1–5 star ratings.
- Discovery surfaces the best content via "Featured" lists (top-rated, most-discussed).
- Derived from the bezKoder Spring Boot + React CRUD sample, extended with comments and ratings.

## Actors

- **Reader** — browses tutorial list and detail, reads comments and ratings. No sign-in.
- **Contributor** — creates, edits, publishes/unpublishes, and deletes tutorials.
- **Commenter** — posts a comment or a reply under a tutorial, giving an author name.
- **Rater** — assigns one star rating (1–5) per tutorial; may change it later.
- No authentication or accounts. Identity is self-declared: the user types a name/email once,
  stored locally on their device, used to attribute comments and enforce one rating per person.

## Domain Terms

- **Tutorial** — a titled entry with a description and a published/unpublished flag.
- **Comment** — text with an author name and timestamp, attached to a tutorial; supports
  nested replies (a comment may reply to another comment).
- **Rating** — a 1–5 star score tied to one self-declared user; at most one per tutorial per user.
- **Rating stats** — aggregate view of a tutorial's ratings (e.g. average, count).
- **Featured** — curated discovery: **Top-rated** (highest average with a minimum rating count)
  and **Most-discussed** (highest comment count).
- **Published** — flag marking a tutorial as visible/complete versus a draft.

## Behavior

- Browse all tutorials; search tutorials by title.
- View a single tutorial with its comments and rating summary.
- Create, edit, and delete a tutorial; delete all tutorials.
- Toggle a tutorial's published state.
- Post comments and threaded replies with an author name; see the comment count.
- Submit or change a star rating; view the tutorial's rating statistics and one's own prior rating.
- Discover Featured tutorials via top-rated and most-discussed lists.

## Target State

- Functional demo/reference app; feature-complete for tutorials + comments + ratings + featured.
- Multiple consistency gaps exist across both modules (styling, error handling, validation,
  configuration) — resolved as target-state direction in `docs/ASSUMPTIONS.md` and
  `docs/ARCHITECTURE.md`; not yet implemented, tracked in `docs/TODO.md`.
- No known production hardening (auth, pagination, environment profiles) yet; deployment is
  explicitly out of scope (local-dev/demo app).

## Related Docs

- Architecture and modules: `docs/ARCHITECTURE.md`
- File layout: `docs/CODEMAP.md` · Tech stack: `docs/TECHSTACK.md` · Deps: `docs/DEPENDENCIES.md`
- Current implementation state: `agents/IMPLEMENTATION.md`
- Open questions and assumptions: `docs/ASSUMPTIONS.md`
- Patterns: `docs/PATTERNS/INDEX.md`

---

MUST USE SKILL `large-workspace-handling` FOR TASKS SPANNING MANY FILES.

MUST USE SKILL CODEMAP AND LSP (jdtls-lsp, typescript-lsp) FOR CODE NAVIGATION.
