# Code Map

## Root (2 independent modules, 66 tracked files)

### react-client/ (33 files)

- **.gitignore**
- **.env**
- **package.json** — npm dependencies, build scripts
- **package-lock.json**
- **yarn.lock**
- **tailwind.config.js** — Tailwind CSS config
- **postcss.config.js** — PostCSS config
- **public/** — Static assets
  - index.html
  - favicon.ico
  - manifest.json
  - robots.txt
  - logo192.png, logo512.png
  - icon.svg
- **src/** — Source code
  - index.js — Entry point
  - App.js — Root component
  - App.css
  - components/ — React components
  - pages/ — Page-level components
  - services/ — API clients (Axios)
- **build/** — Production build output (gitignored in source)

### spring-boot-server/ (26 files)

- **pom.xml** — Maven configuration
- **.gitignore**
- **mvnw, mvnw.cmd** — Maven wrapper
- **.mvn/wrapper/** — Maven wrapper configuration
- **src/main/java/com/bezkoder/spring/datajpa/**
  - SpringBootDataJpaApplication.java — Boot entry point
  - controller/ — REST endpoints
    - TutorialController.java
    - CommentController.java
    - RatingController.java
  - model/ — Domain entities
    - Tutorial.java
    - Comment.java
    - Rating.java
  - repository/ — Spring Data JPA repositories
    - TutorialRepository.java
    - CommentRepository.java
    - RatingRepository.java
  - dto/ — Data transfer objects
    - TutorialStatsDTO.java
    - RatingDTO.java, CreateRatingRequest.java
    - CommentDTO.java, CreateCommentRequest.java
  - config/ — Application configuration
    - WebConfig.java
- **src/main/resources/**
  - application.properties — Spring Boot config
- **src/test/java/**
  - SpringBootDataJpaApplicationTests.java

### Root-level files (7 files)

- **.claude/** — Rosetta plugin config
- **.git/** — Git repository
- **.idea/** — IDE config
- **.gitignore**
- **gain.json** — SDLC setup
- **agents/** — Rosetta agents and state
- **scripts/** — Utility scripts
