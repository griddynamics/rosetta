# ASSUMPTIONS

Explicit assumptions and unknowns inferred from code, not yet confirmed by a human.
Each entry: the assumption/open decision, a confidence level, and the doc to update once resolved.
Phase 8 (Questions) HITL round resolved all D1–D15 and U1 below (2026-07-15); outcomes recorded
and cross-referenced into `docs/ARCHITECTURE.md`. Style: terse, grep-friendly.
A1/A2 (domain assumptions) are unchanged — not part of the Phase 8 decision round.

## Domain / Business

### A1 — App is a tutorial-sharing/knowledge app [High]
Inferred CRUD tutorials + threaded comments + star ratings + featured discovery. No product brief seen.
Resolve into: `docs/CONTEXT.md`.

### A2 — Users are anonymous; self-declared identity is intentional [Medium]
No auth; identity is a prompted name/email in `localStorage`. Assumed by design, not an unfinished feature.
Resolve into: `docs/CONTEXT.md`.

## Resolved Decisions (Phase 8, from Phase 5 pattern extraction)

### D1 — RESOLVED: Tailwind is canonical frontend styling system
`add-tutorial` (pure Bootstrap 4) is a migration gap, not a mandated rewrite. Recorded in
`docs/ARCHITECTURE.md` → Target-State Improvements (react-client).

### D2 — RESOLVED: Function components + hooks are target component paradigm
Class components (`add-tutorial`, `tutorial`, `tutorials-list`, `tutorial-view`, `featured-tutorials`) migrate
opportunistically; not a mandated rewrite. Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D3 — RESOLVED: Consolidate duplicated rating-flow logic
`handleRatingChange` in `tutorial.component.js` and `tutorial-view.component.js` to be consolidated into a
shared hook/util. Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D4 — RESOLVED: All user-triggered failures must surface a user-facing message
Not just `console.log`. Recorded as target UX policy in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D5 — RESOLVED: Split `services/tutorial.service.js` into one service per resource
Tutorial/comment/rating services. Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D6 — RESOLVED: Externalize frontend API base URL
`http-common.js` base URL via `.env`/`REACT_APP_*`. Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D7 — RESOLVED: Add global backend exception handler
`@ControllerAdvice` with structured error body, replacing per-controller `try/catch(Exception) → 500`.
Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D8 — RESOLVED: Standardize 404-mapping idiom on `Optional.isPresent()`
Applies across `CommentController`/`RatingController` (drop `orElseThrow`-catch). Recorded in
`docs/ARCHITECTURE.md` → Target-State Improvements.

### D9 — RESOLVED: Consolidate CORS config to `WebConfig.java` only
Remove per-controller `@CrossOrigin`. Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D10 — RESOLVED: Standardize aggregate endpoint responses on typed DTOs
`RatingController.getRatingStats` and `CommentController.getCommentCount` to return typed DTOs instead of raw
`Map`. Recorded in `docs/ARCHITECTURE.md` → Target-State Improvements.

### D11 — RESOLVED: Adopt Bean Validation instead of duplicated manual checks
`@Min`/`@Max`/`@Valid` to replace the 3x duplicated manual "stars 1–5" check. Recorded in
`docs/ARCHITECTURE.md` → Target-State Improvements.

### D12 — RESOLVED: JPQL repository aggregates are source of truth for stats
`Tutorial.getAverageRating()`/`getCommentCount()` entity-side methods are deprecated/to-remove. Recorded in
`docs/ARCHITECTURE.md` → Target-State Improvements.

### D13 — RESOLVED: Split `application.properties` into Spring profiles
dev=H2, prod=MySQL, replacing the single hardcoded config. Recorded in `docs/ARCHITECTURE.md` → Target-State
Improvements + `docs/TECHSTACK.md`.

### D14 — RESOLVED: Leave `CommentRepository.findByTutorialId` in place
Confirmed unused by any in-scope controller; flagged as dead/unused code here and in
`agents/IMPLEMENTATION.md`. Do not delete.

### D15 — RESOLVED: Add pagination to list endpoints
`getAllTutorials`, `getCommentsByTutorialId`, `getRatingsByTutorialId`. Recorded in `docs/ARCHITECTURE.md` →
Target-State Improvements.

## Unknowns (Resolved)

### U1 — RESOLVED: Deployment/runtime target is local-dev/demo only
No production deployment target recorded; explicitly out of scope. Recorded in `docs/ARCHITECTURE.md`
(Constraints & Gaps) and `docs/TODO.md`.
