# TODO

Improvements and large TODOs not yet implemented. Style: terse, grep-friendly.
Detailed target-state direction lives in `docs/ARCHITECTURE.md` → Target-State Improvements;
resolution history in `docs/ASSUMPTIONS.md`.

## Follow-up (post-workflow)

- **Regenerate READMEs**: root, `react-client/`, `spring-boot-server/` — removed at baseline, not
  recreated during `init-workspace-flow`. Do after this workflow completes (Phase 8 decision).

## Improvement Backlog (target-state, not yet implemented)

Cross-reference: `docs/ARCHITECTURE.md` → Target-State Improvements, `docs/ASSUMPTIONS.md` D1–D15.

### react-client

- Migrate `add-tutorial.component.js` off Bootstrap-only styling toward Tailwind (D1).
- Migrate class components to function components + hooks, opportunistically (D2).
- Consolidate duplicated `handleRatingChange` into a shared hook/util (D3).
- Surface all user-triggered failures as user-facing messages, not just `console.log` (D4).
- Split `services/tutorial.service.js` into one service per resource (D5).
- Externalize API base URL (`http-common.js`) via `.env`/`REACT_APP_*` (D6).

### spring-boot-server

- Add global `@ControllerAdvice` exception handler with structured error body (D7).
- Standardize 404 mapping on `Optional.isPresent()` across all controllers (D8).
- Consolidate CORS config to `WebConfig.java` only (D9).
- Standardize aggregate responses on typed DTOs (D10).
- Adopt Bean Validation (`@Min`/`@Max`/`@Valid`) for rating stars (D11).
- Remove `Tutorial.getAverageRating()`/`getCommentCount()` entity-side methods once callers migrate to
  JPQL aggregates (D12).
- Split `application.properties` into Spring profiles: dev=H2, prod=MySQL (D13).
- Add pagination to `getAllTutorials`, `getCommentsByTutorialId`, `getRatingsByTutorialId` (D15).

### Testing

- Grow backend tests beyond the context-load smoke test (controller/repository/entity coverage).
- Add meaningful frontend component tests (RTL/Jest already available).
- No fixed coverage percentage target — goal is "meaningful test coverage" (see `agents/IMPLEMENTATION.md`).

## Explicitly Out of Scope

- Production deployment target (local-dev/demo only; see `docs/ASSUMPTIONS.md` U1).
- Deleting `CommentRepository.findByTutorialId` (unused but left in place; see `docs/ASSUMPTIONS.md` D14).
