# Dependencies

## Backend (spring-boot-server)

### Direct Maven Dependencies

| Package | Version | Scope | Purpose |
|---------|---------|-------|---------|
| org.springframework.boot:spring-boot-starter-data-jpa | 3.1.0 (parent) | compile | ORM, JPA support |
| org.springframework.boot:spring-boot-starter-web | 3.1.0 (parent) | compile | REST endpoints |
| com.mysql:mysql-connector-j | default | runtime | MySQL driver |
| com.h2database:h2 | default | runtime | In-memory DB |
| org.springframework.boot:spring-boot-starter-test | 3.1.0 (parent) | test | JUnit, testing |

### Transitive (via parent)

- Spring Framework 6.0.x
- Hibernate ORM
- Jackson (JSON)
- Tomcat (embedded servlet)

## Frontend (react-client)

### Direct npm Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | 18.2.0 | UI framework |
| react-dom | 18.2.0 | React DOM binding |
| react-router-dom | 6.4.0 | Routing |
| axios | 0.27.2 | HTTP client |
| bootstrap | 4.6.2 | CSS framework |
| react-scripts | 5.0.1 | Build tooling |

### Dev Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| tailwindcss | 3.4.18 | Utility CSS |
| postcss | 8.5.6 | CSS transformation |
| autoprefixer | 10.4.22 | CSS prefixing |

### Testing

| Package | Version | Purpose |
|---------|---------|---------|
| @testing-library/react | 13.0.1 | Component testing |
| @testing-library/jest-dom | 5.16.4 | DOM matchers |
| @testing-library/user-event | 14.1.1 | User interaction simulation |

### Transitive (via react-scripts)

- Webpack, Babel
- ESLint
- Jest (test runner)
- Web vitals
