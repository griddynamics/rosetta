# Controller-Level Entity-to-DTO Mapping

## Description

Entity to DTO conversion is done by a private `convertToDTO(Entity e)` helper method inside the controller itself (not a mapper/service class); recursive collections (e.g. replies) are mapped via `.stream().map(this::convertToDTO)`.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/CommentController.java` (lines 100-116)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/RatingController.java` (lines 132-140)

## Template

```java
private XDTO convertToDTO(X entity) {
    XDTO dto = new XDTO();
    dto.setId(entity.getId());
    dto.setField(entity.getField());
    dto.setParentId(entity.getParent() != null ? entity.getParent().getId() : null);
    // recursive: dto.setChildren(entity.getChildren().stream().map(this::convertToDTO).collect(toList()));
    return dto;
}
```
