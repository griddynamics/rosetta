# Response DTO / Create-Request DTO Split

## Description

Read endpoints return plain-POJO `*DTO` classes (flattening entity relations to a `Long <parent>Id` field instead of nested entities) while write endpoints accept separate `Create*Request` classes; both are hand-written POJOs with no-arg + full constructors and getters/setters, no validation annotations.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/dto/RatingDTO.java` + `CreateRatingRequest.java`
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/dto/CommentDTO.java` + `CreateCommentRequest.java`

## Template

```java
public class <Entity>DTO {
    private long id;
    private String field;
    private Long parentEntityId; // flattened FK, not nested object
    // no-arg ctor, full ctor, getters/setters
}

public class Create<Entity>Request {
    private String field;
    private Long parentId; // optional, e.g. null for top-level
    // no-arg ctor, full ctor, getters/setters
}
```

## Related Gap

No Bean Validation (`@Min`/`@Max`/`@Valid`) is used on these DTOs despite `jakarta.persistence` being on the classpath; see Gaps Log entry "Validation duplicated across layers, no Bean Validation used".
