# JPA Entity Convention

## Description

Entities use `@Entity`/`@Table(name=...)`, `@GeneratedValue(strategy = GenerationType.AUTO)` id, explicit `@Column(name=...)`, `@JsonIgnore` on the owning side of relations (to avoid serializing back-references/lazy proxies), and both a no-arg and a field constructor.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/model/Tutorial.java` (lines 8-41)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/model/Comment.java` (lines 9-56)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/model/Rating.java` (lines 7-43)

## Template

```java
@Entity
@Table(name = "<table>")
public class <Entity> {
    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "<col>")
    private String field;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "<parent>_id")
    private <Parent> parent;

    public <Entity>() { }
    public <Entity>(String field, <Parent> parent) { ... }
    // getters/setters
}
```
