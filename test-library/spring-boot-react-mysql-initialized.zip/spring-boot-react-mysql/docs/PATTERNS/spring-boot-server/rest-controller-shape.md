# REST Controller Shape

## Description

All controllers follow the same class-level and dependency-wiring skeleton: `@CrossOrigin` + `@RestController` + `@RequestMapping("/api")`, with field-injected `@Autowired` repositories (no constructor injection) and `ResponseEntity<T>` return types for every handler.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/TutorialController.java` (lines 27-39)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/CommentController.java` (lines 20-29)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/RatingController.java` (lines 20-29)

## Template

```java
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8081"})
@RestController
@RequestMapping("/api")
public class <Entity>Controller {

    @Autowired
    private <Entity>Repository <entity>Repository;
    // additional @Autowired repositories as needed for cross-entity lookups

    @GetMapping("/<entities>/{id}")
    public ResponseEntity<X> handler(@PathVariable("id") long id) { ... }
}
```
