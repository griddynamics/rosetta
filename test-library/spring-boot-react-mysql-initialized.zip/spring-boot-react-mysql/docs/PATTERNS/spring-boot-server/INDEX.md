# spring-boot-server Patterns Index

## REST Controller Shape - CrossOrigin + RestController + RequestMapping("/api") skeleton with field-injected repositories

See `rest-controller-shape.md`.

## Manual ResponseEntity / HttpStatus Response Construction - hand-built ResponseEntity per outcome wrapped in try/catch(Exception) -> 500

See `manual-responseentity-construction.md`.

## JPA Entity Convention - Entity/Table/GeneratedValue/Column/JsonIgnore conventions with no-arg and field constructors

See `jpa-entity-convention.md`.

## Spring Data Repository: Derived Queries + JPQL Aggregates - JpaRepository with derived findBy/countBy methods plus @Query JPQL returning Object[] aggregates

See `repository-derived-queries-jpql-aggregates.md`.

## Response DTO / Create-Request DTO Split - flattened *DTO for reads, separate Create*Request for writes, no validation annotations

See `dto-split-response-create.md`.

## Controller-Level Entity-to-DTO Mapping - private convertToDTO helper inside the controller, recursive for nested collections

See `controller-level-entity-to-dto-mapping.md`.

## Cross-Entity Aggregation into a Composite Stats DTO - fan-out across repositories, loop raw Object[] rows, re-fetch parent entity for display fields

See `cross-entity-aggregation-stats-dto.md`.
