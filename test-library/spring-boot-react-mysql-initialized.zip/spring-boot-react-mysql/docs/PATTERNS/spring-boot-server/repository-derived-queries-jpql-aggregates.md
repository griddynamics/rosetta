# Spring Data Repository: Derived Queries + JPQL Aggregates

## Description

Repositories extend `JpaRepository<T, Long>` and mix Spring Data derived-query method names (`findByX`, `countByX`) with explicit `@Query` JPQL for aggregates that return `List<Object[]>` (grouped/joined stats) rather than projections/DTOs at the query layer.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/repository/CommentRepository.java` (lines 10-27)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/repository/RatingRepository.java` (lines 10-32)

## Template

```java
public interface <Entity>Repository extends JpaRepository<<Entity>, Long> {
    List<<Entity>> findBy<Field>(<Type> value);
    long countBy<ParentRef>Id(Long id);

    @Query("SELECT e.<parent>.id, AGG(e.<field>) FROM <Entity> e GROUP BY e.<parent>.id ORDER BY 2 DESC")
    List<Object[]> find<Aggregate>();
}
```

## Related Gap

`Tutorial` entity also recomputes some of these aggregates in Java from lazily-loaded collections; see Gaps Log entry "Two divergent ways to compute the same statistic".
