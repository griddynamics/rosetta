# Manual ResponseEntity / HttpStatus Response Construction

## Description

Handlers build `ResponseEntity` by hand for every outcome (200/201/204/404/500) rather than relying on a global handler; a top-level `try { ... } catch (Exception e) { return 500 }` wraps most handler bodies.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/TutorialController.java` (lines 42-59, 108-117)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/RatingController.java` (lines 72-82, 121-129)

## Template

```java
@GetMapping("/<path>")
public ResponseEntity<X> handler(...) {
    try {
        X result = repository.someOperation(...);
        if (/* empty/absent */) return new ResponseEntity<>(HttpStatus.NO_CONTENT); // or NOT_FOUND
        return new ResponseEntity<>(result, HttpStatus.OK);
    } catch (Exception e) {
        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
```

## Related Gap

No `@ControllerAdvice`/global exception handler exists; see Gaps Log entry "No global exception handler".
