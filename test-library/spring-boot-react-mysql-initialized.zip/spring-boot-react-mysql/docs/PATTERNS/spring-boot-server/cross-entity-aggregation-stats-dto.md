# Cross-Entity Aggregation into a Composite Stats DTO

## Description

A single endpoint fans out to multiple repositories to assemble a composite read-model DTO (id/title from one entity, aggregate numbers from others), looping over raw `Object[]` query results and re-fetching the parent entity by id for display fields.

## Evidence

- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/controller/TutorialController.java` — `getTopRatedTutorials` (lines 133-171) and `getMostDiscussedTutorials` (lines 173-211)
- `spring-boot-server/src/main/java/com/bezkoder/spring/datajpa/dto/TutorialStatsDTO.java`

## Template

```java
List<Object[]> rows = someRepository.findAggregateRows(...);
List<StatsDTO> out = new ArrayList<>();
for (Object[] row : rows) {
    Long id = ((Number) row[0]).longValue();
    // extract remaining aggregate columns via ((Number) row[n]).xValue()
    otherRepository.findById(id).ifPresent(entity ->
        out.add(new StatsDTO(id, entity.getTitle(), /* aggregates */)));
}
```
