# Pattern Changes Log

## [2026-07-15] Initial pattern extraction (install mode)

- Created `docs/PATTERNS/INDEX.md` (top-level, composite-aware)
- Created `docs/PATTERNS/react-client/INDEX.md` and 6 pattern files: API Service Module (Axios Singleton), Class-Component Data-Fetch Lifecycle, withRouter HOC for Class Components, Confirm-Before-Destroy Guard, Ephemeral Auto-Dismiss Status Message, Anonymous-User Identity via localStorage + prompt()
- Created `docs/PATTERNS/spring-boot-server/INDEX.md` and 7 pattern files: REST Controller Shape, Manual ResponseEntity/HttpStatus Response Construction, JPA Entity Convention, Spring Data Repository: Derived Queries + JPQL Aggregates, Response DTO / Create-Request DTO Split, Controller-Level Entity-to-DTO Mapping, Cross-Entity Aggregation into a Composite Stats DTO
- No pre-existing `docs/PATTERNS/` content — nothing skipped, nothing overwritten
- 15 gaps identified during extraction and logged to `agents/init-workspace-flow-state.md` Gaps Log for Phase 8 review (not resolved in this phase)
