# Patterns Index

Composite workspace: patterns are extracted per sub-repository. 13 patterns total across 2 modules.

## react-client - 6 patterns covering API service modules, class-component data fetching, routing, destructive-action guards, status messaging, and anonymous identity

See `react-client/INDEX.md` for the full list and `react-client/*.md` for individual pattern files.

## spring-boot-server - 7 patterns covering REST controller shape, response construction, JPA entities, repositories, DTOs, and cross-entity aggregation

See `spring-boot-server/INDEX.md` for the full list and `spring-boot-server/*.md` for individual pattern files.

## Gaps Log Cross-Reference

Inconsistencies and ambiguities found during extraction (styling system split, class-vs-hooks components, duplicated rating logic, error-handling inconsistency, missing global exception handler, no Bean Validation, hardcoded API URL and CORS config, non-externalized profiles, and more) are logged in `agents/init-workspace-flow-state.md` under "Gaps Log" for Phase 8 review, not resolved here.
