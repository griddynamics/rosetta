# Confirm-Before-Destroy Guard

## Description

Destructive actions (bulk delete, single delete) are gated behind a synchronous `window.confirm(...)` before the service call fires. Use for any irreversible delete action to avoid a separate modal-confirmation component.

## Evidence

- `react-client/src/components/tutorials-list.component.js` (`removeAllTutorials`)
- `react-client/src/components/comments.component.js` (`handleDelete`)

## Template

```js
const handleDelete = (id) => {
  if (window.confirm("Are you sure? This action cannot be undone.")) {
    ResourceService.delete(id).then(() => refreshList()).catch(e => console.log(e));
  }
};
```
