# Anonymous-User Identity via localStorage + prompt()

## Description

Before submitting a rating, the component checks `state.username` (seeded from `localStorage.getItem('username')`); if empty, it blocks via `window.prompt`, persists the name to `localStorage`, then proceeds with the mutation. Use for any anonymous-identity-gated write action where there is no auth system.

## Evidence

- `react-client/src/components/tutorial.component.js` (`handleRatingChange`, approx. lines 141-170)
- `react-client/src/components/tutorial-view.component.js` (`handleRatingChange`, approx. lines 80-109) — near-verbatim duplicate of the above (see Gaps Log)

## Template

```js
handleRatingChange(stars) {
  let { username } = this.state;
  if (!username?.trim()) {
    const name = prompt('Please enter your name to rate:');
    if (!name?.trim()) return;
    username = name;
    this.setState({ username: name });
    localStorage.setItem('username', name);
  }
  RatingService.createOrUpdate(this.state.currentTutorial.id, { stars, userIdentifier: username })
    .then(() => { this.setState({ userRating: stars, message: "..." }); /* auto-dismiss */ })
    .catch(e => console.log(e));
}
```
