# Ephemeral Auto-Dismiss Status Message

## Description

A `message`/`setMessage` piece of state is set after an async mutation (create/rate/reply/delete) and cleared automatically via `setTimeout(..., 3000)`, rendered as a Bootstrap alert or plain text banner. Use for lightweight non-blocking success/error feedback without a toast library.

## Evidence

- `react-client/src/components/comments.component.js` (`handleSubmit`, `handleReply`, `handleDelete`)
- `react-client/src/components/tutorial.component.js` and `tutorial-view.component.js` (`handleRatingChange`)

## Template

```js
this.setState({ message: "Action completed successfully!" });
setTimeout(() => this.setState({ message: "" }), 3000); // extension point: vary delay/copy per action
// render: {message && <div className="alert alert-success" role="alert">{message}</div>}
```
