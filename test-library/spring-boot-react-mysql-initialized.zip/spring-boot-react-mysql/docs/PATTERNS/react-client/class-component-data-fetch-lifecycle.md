# Class-Component Data-Fetch Lifecycle

## Description

Class components bind handlers in the constructor, fetch data in `componentDidMount`, store results in `state`, and resolve/reject with `.then(response => this.setState(...)).catch(e => console.log(e))`. Use for any class-based page/component that loads server data on mount.

## Evidence

- `react-client/src/components/tutorials-list.component.js` (`retrieveTutorials`)
- `react-client/src/components/tutorial-view.component.js` (`getTutorial`, `loadRatingStats`)
- `react-client/src/components/featured-tutorials.component.js` (`loadFeaturedTutorials`)

## Template

```js
constructor(props) {
  super(props);
  this.loadData = this.loadData.bind(this);
  this.state = { items: [], loading: false };
}
componentDidMount() { this.loadData(); }
loadData() {
  this.setState({ loading: true });
  ResourceService.getAll()
    .then(response => this.setState({ items: response.data, loading: false }))
    .catch(e => { console.log(e); this.setState({ loading: false }); }); // extension point: user-facing error state
}
```
