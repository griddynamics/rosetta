# API Service Module (Axios Singleton)

## Description

Centralizes all backend HTTP calls behind one exported singleton object built on a shared pre-configured Axios instance. Use for any new REST resource so components never call `axios`/`fetch` directly.

## Evidence

- `react-client/src/http-common.js`
- `react-client/src/services/tutorial.service.js`

## Template

```js
// http-common.js
import axios from "axios";
export default axios.create({
  baseURL: "http://localhost:8080/api",
  headers: { "Content-type": "application/json" },
});

// <resource>.service.js
import http from "../http-common";
class ResourceDataService {
  getAll() { return http.get("/resource"); }
  get(id) { return http.get(`/resource/${id}`); }
  create(data) { return http.post("/resource", data); }
  update(id, data) { return http.put(`/resource/${id}`, data); }
  delete(id) { return http.delete(`/resource/${id}`); }
  // extension point: add nested-resource methods here (see comments/ratings in tutorial.service.js)
}
export default new ResourceDataService();
```
