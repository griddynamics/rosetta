# react-client Patterns Index

## API Service Module (Axios Singleton) - centralizes REST calls per resource behind one exported service object built on a shared Axios instance

See `api-service-module.md`.

## Class-Component Data-Fetch Lifecycle - constructor-bind, componentDidMount fetch, then/catch into setState

See `class-component-data-fetch-lifecycle.md`.

## withRouter HOC for Class Components - gives class components access to React Router v6 hooks via a wrapping function component

See `with-router-hoc.md`.

## Confirm-Before-Destroy Guard - window.confirm gate before any irreversible delete call

See `confirm-before-destroy-guard.md`.

## Ephemeral Auto-Dismiss Status Message - setState message + setTimeout(3000) clear for lightweight success/error feedback

See `ephemeral-auto-dismiss-status-message.md`.

## Anonymous-User Identity via localStorage + prompt() - window.prompt-gated identity capture persisted to localStorage before a rating write

See `anonymous-user-identity-localstorage-prompt.md`.
