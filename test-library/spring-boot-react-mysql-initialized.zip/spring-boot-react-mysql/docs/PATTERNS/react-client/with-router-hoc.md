# withRouter HOC for Class Components

## Description

Wraps a class component so it can access React Router v6 hooks (`useParams`/`useNavigate`/`useLocation`), which are otherwise hook-only. Use whenever a class component (not refactored to function+hooks) needs route params or programmatic navigation.

## Evidence

- `react-client/src/common/with-router.js`
- `react-client/src/components/tutorial.component.js` (`export default withRouter(Tutorial)`)
- `react-client/src/components/tutorial-view.component.js` (`export default withRouter(TutorialView)`)

## Template

```js
// common/with-router.js
export const withRouter = (Component) => (props) => {
  const location = useLocation(), navigate = useNavigate(), params = useParams();
  return <Component {...props} router={{ location, navigate, params }} />;
};

// usage in a class component:
// this.props.router.params.id
// this.props.router.navigate('/path')
export default withRouter(MyClassComponent);
```
