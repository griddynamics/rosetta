# ARCHITECTURE

Technical architecture: modules, structure, boundaries, decisions, constraints — the "how".
No business context (see `docs/CONTEXT.md`). No file-by-file listing (see `docs/CODEMAP.md`).
Style: terse, grep-friendly. Always loaded into agent context.

## Shape

- Composite workspace: two independent modules under one repo root.
  - `react-client/` — React 18 SPA (frontend).
  - `spring-boot-server/` — Spring Boot 3.1 REST API (backend).
- Frontend talks to backend over HTTP/JSON REST under base path `/api`.
- Backend persists to a relational DB via JPA/Hibernate.

## Module Registry

| Module | Role | Stack | Entry point |
|---|---|---|---|
| `react-client/` | SPA UI | React 18.2, React Router 6.4, Axios 0.27 | `src/index.js` → `src/App.js` |
| `spring-boot-server/` | REST API + persistence | Spring Boot 3.1.0, Java 17, Spring Data JPA | `SpringBootDataJpaApplication.java` |

Details: `docs/CODEMAP.md`, `docs/TECHSTACK.md`, `docs/DEPENDENCIES.md`.
Patterns per module: `docs/PATTERNS/react-client/INDEX.md`, `docs/PATTERNS/spring-boot-server/INDEX.md`.

## Backend (`spring-boot-server`)

- Layered: `controller` (REST) → `repository` (Spring Data JPA) → `model` (JPA entities); `dto` for wire shapes; `config` for cross-cutting.
- Package root: `com.bezkoder.spring.datajpa`.
- Entities: `Tutorial` (1—*) `Comment` (self-referencing parent/replies), `Tutorial` (1—*) `Rating`.
  - `Rating` has a unique constraint on `(tutorial_id, user_identifier)` → one rating per user per tutorial (upsert semantics).
  - Entity collections are `@JsonIgnore`, `LAZY`; controllers map entities to DTOs before returning.
- Controllers: `TutorialController`, `CommentController`, `RatingController`, all under `/api`.
  - Manual `ResponseEntity`/`HttpStatus` construction per outcome, wrapped in `try/catch(Exception) → 500`.
  - No `@ControllerAdvice`; no Bean Validation (`@Valid`) — validation is hand-coded.
- Repositories: `JpaRepository` with derived `findBy`/`countBy` methods plus `@Query` JPQL aggregates for stats (top-rated, most-discussed, rating stats).
- Persistence: JPA/Hibernate; schema auto-managed. See "Constraints" for DB profile status.

### REST surface (under `/api`)

- Tutorials: `GET/POST /tutorials`, `GET/PUT/DELETE /tutorials/{id}`, `DELETE /tutorials`, `GET /tutorials?title=`, `GET /tutorials/top-rated`, `GET /tutorials/most-discussed`.
- Comments: `GET/POST /tutorials/{id}/comments`, `GET /tutorials/{id}/comments/count`, `DELETE /comments/{id}`.
- Ratings: `GET/POST /tutorials/{id}/ratings`, `GET /tutorials/{id}/ratings/stats`, `GET /tutorials/{id}/ratings/user/{userIdentifier}`, `DELETE /ratings/{id}`.

## Frontend (`react-client`)

- SPA with client-side routing (React Router v6). Routes in `src/App.js`:
  - `/` and `/featured` → FeaturedTutorials · `/tutorials` → list · `/add` → create · `/tutorials/:id` → view · `/tutorials/:id/edit` → edit.
- Data access via a single Axios service singleton (`services/tutorial.service.js`) over a shared instance (`http-common.js`).
- Mostly class components using constructor-bind + `componentDidMount` fetch → `setState`; a `withRouter` HOC bridges class components to Router v6 hooks. Two components (`comments`, `star-rating`) are function components with hooks.
- Anonymous identity captured via `window.prompt` and persisted to `localStorage` before a rating write.

## Key Decisions & Conventions

- REST/JSON contract under `/api`; DTOs decouple wire shape from JPA entities.
- One rating per user per tutorial enforced at the DB (unique constraint) with create-or-update behavior.
- Threaded comments modeled by a self-referencing `Comment.parent`/`replies`.
- Destructive UI actions gated by `window.confirm`; transient status messages auto-dismiss after ~3s.

## Constraints & Gaps (current state; target direction below)

- DB: `application.properties` ships with H2 active and MySQL commented out; no Spring profiles. MySQL is the apparent real target.
- CORS declared twice (per-controller `@CrossOrigin` and global `config/WebConfig.java`) with differing origin order.
- Frontend API base URL hardcoded (`http://localhost:8080/api`); no env indirection.
- No global exception handler, no Bean Validation, no pagination on list endpoints.
- Mixed styling systems (Bootstrap 4 + Tailwind) and mixed component paradigms (class vs hooks).
- Deployment: local-dev/demo only. No production deployment target recorded — explicitly out of scope
  (Phase 8 decision, resolves `docs/ASSUMPTIONS.md` U1).

## Target-State Improvements (Phase 8 decisions, not yet implemented)

Direction only — no code changed under this decision round. Source: `docs/ASSUMPTIONS.md` D1–D15.

### react-client

- **Styling**: Tailwind is canonical. Bootstrap-only components (`add-tutorial.component.js`) are a
  migration gap, migrated opportunistically (D1).
- **Components**: function components + hooks are the target convention. Class components migrate
  opportunistically — not a mandated rewrite (D2).
- **Rating logic**: consolidate duplicated `handleRatingChange` (`tutorial.component.js` +
  `tutorial-view.component.js`) into a shared hook/util (D3).
- **Error handling**: all user-triggered failures must surface a user-facing message, not just
  `console.log` (D4).
- **Services**: split `services/tutorial.service.js` into one service per resource — tutorial, comment,
  rating (D5).
- **Config**: externalize API base URL (`http-common.js`) via `.env`/`REACT_APP_*` (D6).

### spring-boot-server

- **Errors**: add a global `@ControllerAdvice` exception handler with a structured error body (D7).
- **404 mapping**: standardize on `Optional.isPresent()` across `CommentController`/`RatingController`,
  removing the `orElseThrow`-catch idiom (D8).
- **CORS**: consolidate to `WebConfig.java` only; remove per-controller `@CrossOrigin` (D9).
- **Response shape**: standardize aggregate endpoints (`RatingController.getRatingStats`,
  `CommentController.getCommentCount`) on typed DTOs instead of raw `Map` (D10).
- **Validation**: adopt Bean Validation (`@Min`/`@Max`/`@Valid`) instead of the 3x duplicated manual
  "stars 1–5" check (D11).
- **Stats source of truth**: JPQL repository aggregates are canonical; `Tutorial.getAverageRating()`/
  `getCommentCount()` entity-side methods are deprecated/to-remove (D12).
- **Config**: split `application.properties` into Spring profiles — dev=H2, prod=MySQL (D13).
- **Pagination**: add to `getAllTutorials`, `getCommentsByTutorialId`, `getRatingsByTutorialId` (D15).
- **Dead code**: `CommentRepository.findByTutorialId` is unused; left in place, not deleted (D14).

## Testing

- Backend: JUnit via `spring-boot-starter-test`; only a context-load smoke test (`SpringBootDataJpaApplicationTests`) present.
- Frontend: React Testing Library + Jest available (via react-scripts); no meaningful component tests present.

## Build & Run

- Backend: Maven (`./mvnw`), `pom.xml`. Frontend: npm (`package.json`, react-scripts).
