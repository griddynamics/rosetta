# Tech Stack

## Summary

Spring Boot 3.1.0 backend (Java 17) with React 18.2.0 frontend using MySQL database and REST API integration via Axios.

## Backend (spring-boot-server)

| Component | Version | Purpose |
|-----------|---------|---------|
| Spring Boot | 3.1.0 | Application framework |
| Java | 17 | Runtime |
| Spring Data JPA | (parent) | ORM and data access |
| Spring Web | (parent) | REST endpoints |
| MySQL Connector | (runtime) | Database driver |
| H2 Database | (runtime) | In-memory test database |
| JUnit | (test) | Testing framework |

## Frontend (react-client)

| Component | Version | Purpose |
|-----------|---------|---------|
| React | 18.2.0 | UI framework |
| React Router | 6.4.0 | Client-side routing |
| Axios | 0.27.2 | HTTP client |
| Bootstrap | 4.6.2 | CSS framework |
| Tailwind CSS | 3.4.18 | Utility CSS |
| React Scripts | 5.0.1 | Build tooling |

## Build & Package Management

- Backend: Maven (via pom.xml, mvnw wrapper)
- Frontend: npm (via package.json)

## Databases

- MySQL (production)
- H2 (test/in-memory)
